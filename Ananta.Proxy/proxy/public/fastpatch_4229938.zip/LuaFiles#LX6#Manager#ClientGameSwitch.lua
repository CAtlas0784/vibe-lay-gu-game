-- Ananta private-server fastpatch for client 4229938
-- GameSwitch defaults, Gacha active pool bypass, and safety hooks.

local M = {}

M.Sync = function(key, value)
    M[key] = value

    pcall(function()
        if gMessageManager and gEventConstants and gEventConstants.ON_GM_GAME_SWITCH_CHANGE then
            gMessageManager:SendMessage(gEventConstants.ON_GM_GAME_SWITCH_CHANGE)
        end
    end)
end

M.EnableBuzzCenter = true
M.EnableMall = true
M.EnableMallBundle = true
M.EnableMallRecommend = true
M.EnableMallDirectSale = true
M.EnableCheckIn = true
M.EnableTime = true
M.EnableDossier = true
M.EnableRadiantChest = true
M.EnableCloset = true
M.EnableGachaSystem = true
M.EnableSeasonalBattlePass = true
M.EnableBBChat = true
M.EnableScope = true
M.EnableParty = true
M.EnableSpiritTalent = true
M.EnablePhoto = true
M.EnableMail = true
M.EnablePhone = true
M.EnableFriends = true
M.EnableAchievement = true
M.EnableTutorial = true
M.EnableCityPedia = true
M.EnableNotices = true
M.EnableCustom = true
M.EnableInteractionAction = true
M.EnableDutyTerminal = true
M.EnableCatExpress = true
M.EnableEonBug = true
M.EnableJanitor = true
M.EnableRadioStation = true
M.EnableBubble = true
M.EnableFashionStore = true
M.Enable4SStore = true
M.EnableProfile = true
M.EnableClub = true
M.EnableRanking = true
M.EnableAkashicSystem = true
M.EnableActivity = true

gGameSwitch = M

local ProcessDebugCommand
local function CheckCustomHotkeys()
end

-- Bypass CBT date expiration for Gacha pools and unlock all map/systems
local function ApplyAllGlobalHooks()
    pcall(function()
        if C_GachaManager then
            C_GachaManager.IsPoolActive = function() return true end
            C_GachaManager.CheckHasActiveClosetPool = function() return true end
        end
    end)
    pcall(function()
        if gBlockMgr then
            gBlockMgr.IsBlockUnlocked = function(self, blockId) return true end
        end
    end)
    pcall(function()
        if MapView then
            MapView.InFog = function(self, instanceId) return false end
            MapView.SetFogEnable = function(self, enable) self.enableFog = false end
        end
    end)
    pcall(function()
        if gMapSystem_FogMap then
            gMapSystem_FogMap.IsUnlocked = function(self, sceneId, x, z) return true end
        end
    end)
    pcall(function()
        if gMapUtils then
            gMapUtils.IsEntranceUnlocked = function(self, id) return true end
            gMapUtils.IsEntranceVisible = function(self, id) return true end
            gMapUtils.IsInUnlockBlockNear = function(self, blockId) return true end
        end
    end)
    pcall(function()
        if C_SystemUnlockMgr then
            C_SystemUnlockMgr.IsUnlock = function(self, id) return true end
            C_SystemUnlockMgr.IsUnlockGroup = function(self, ids) return true end
        end
    end)
    pcall(function()
        if C_CharMotionListPanelStore then
            C_CharMotionListPanelStore.CheckActionHasUnlocked = function(self, id) return true end
            C_CharMotionListPanelStore.CheckHasMeetFavor = function(self, id) return true end
        end
    end)
    pcall(function()
        if gMainPhoneUtils then
            gMainPhoneUtils.CheckSkinPartAvailable = function(targetSkinPartId) return true end
            gMainPhoneUtils.CheckAppCanShow = function(appId) return true end
            gMainPhoneUtils.CheckAppCanUse = function(appId) return true end
            gMainPhoneUtils.CheckAppSystemUnlocked = function(appId) return true end
        end
    end)
    pcall(function()
        if gTakePhotoUtils then
            gTakePhotoUtils.isDebugForce = true
            gTakePhotoUtils.PhotoPermission = true
        end
    end)
    pcall(function()
        if gTimeAppUtils then
            gTimeAppUtils.CheckIsTaskForbiddenChangeTime = function() return false end
        end
    end)
    pcall(function()
        if gMapSystem then
            gMapSystem.CanShowVehicleNavRoute = function(self) return true end
            gMapSystem.CheckCanShowVehicleNavLine = function(self) return true end
            if gMapSystem.fogMap then
                gMapSystem.fogMap.IsUnlocked = function(self, sceneId, x, z) return true end
            end
        end
        if LX6 and LX6.Gps and LX6.Gps.MapFogDataMgr then
            LX6.Gps.MapFogDataMgr.IsInFog = function(sceneId, x, z) return false end
            pcall(function() LX6.Gps.MapFogDataMgr.SyncUnlockScene(101, true) end)
            pcall(function() LX6.Gps.MapFogDataMgr.SyncUnlockScene(102, true) end)
            pcall(function() LX6.Gps.MapFogDataMgr.SyncUnlockScene(103, true) end)
            pcall(function() LX6.Gps.MapFogDataMgr.SyncUnlockScene(1001, true) end)
        end
        if C_MapView_Fog then
            C_MapView_Fog.InFog = function(self, instanceId) return false end
            C_MapView_Fog.SetFogEnable = function(self, enable) end
        end
        if gCS and gCS.LuaUtils then
            gCS.LuaUtils.IsNotUseGM = false
        end
        local mapStore = GroupName2Class and GroupName2Class.NewMapPanelStore or C_NewMapPanelStore
        if mapStore and not mapStore._teleportHooked then
            mapStore._teleportHooked = true
            local origOnShow = mapStore.OnShow
            mapStore.OnShow = function(self, ...)
                pcall(function()
                    if self.fogNode then self.fogNode:SetActive(false) end
                    if self.fogRoot then self.fogRoot:SetActive(false) end
                end)
                if origOnShow then return origOnShow(self, ...) end
            end
            local origOnMainClick = mapStore.OnMainClick
            mapStore.OnMainClick = function(self, evtData)
                local isAlt = false
                pcall(function()
                    if UnityEngine and UnityEngine.Input and UnityEngine.KeyCode then
                        isAlt = UnityEngine.Input.GetKey(UnityEngine.KeyCode.LeftAlt) or UnityEngine.Input.GetKey(UnityEngine.KeyCode.RightAlt) or UnityEngine.Input.GetKey(308) or UnityEngine.Input.GetKey(307)
                    end
                end)
                if isAlt or (evtData and evtData.button == 1) then
                    local worldX, worldZ = nil, nil
                    pcall(function()
                        local uiPos = self.GetPointerUIPos and self:GetPointerUIPos()
                        local mousePos = (evtData and evtData.position) or (UnityEngine and UnityEngine.Input and UnityEngine.Input.mousePosition)
                        if not uiPos and mousePos and gCS and gCS.LuaUtils and self.bindData and self.bindData.rootRT then
                            uiPos = gCS.LuaUtils.TransformScreenPointToUI(self.bindData.rootRT, mousePos)
                        end
                        if uiPos and self.TransformUIToTex then
                            local texPos = self:TransformUIToTex(uiPos)
                            if texPos then
                                if self.bindData and self.bindData.bigWorldBg and self.bindData.bigWorldBg.LuaTryGetWorldPos then
                                    local suc, areaId, wx, wz = self.bindData.bigWorldBg:LuaTryGetWorldPos(texPos.x, texPos.y)
                                    if suc and wx and wz and (math.abs(wx) > 0.1 or math.abs(wz) > 0.1) then
                                        worldX, worldZ = wx, wz
                                    end
                                end
                                if not worldX and self.TryTransformTexToWorld then
                                    local areaId, wPos = self:TryTransformTexToWorld(texPos)
                                    if wPos and (math.abs(wPos.x) > 0.1 or math.abs(wPos.z) > 0.1) then
                                        worldX, worldZ = wPos.x, wPos.z
                                    end
                                end
                            end
                        end
                    end)
                    if worldX and worldZ and (math.abs(worldX) > 0.1 or math.abs(worldZ) > 0.1) then
                        local playerY = 274.6
                        pcall(function()
                            local p = gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit and gCS.MyPlayerManager.PlayerUnit.Pos
                            if p and p.y > 10 then playerY = p.y end
                        end)
                        pcall(function()
                            if gClientToGameSceneGMDelegate and gClientToGameSceneGMDelegate.GmTeleportXYZ then
                                gClientToGameSceneGMDelegate:GmTeleportXYZ(worldX, playerY, worldZ, 0)
                            end
                        end)
                        pcall(function()
                            if gCS and gCS.GmUtils and gCS.GmUtils.TeleportXYZ then
                                gCS.GmUtils.TeleportXYZ(worldX, playerY, worldZ, 0)
                            end
                        end)
                        pcall(function()
                            if gDisplayMessageMgr and gDisplayMessageMgr.ShowMessageContent then
                                gDisplayMessageMgr:ShowMessageContent(string.format("Map Teleport: X=%.1f, Z=%.1f", worldX, worldZ))
                            end
                        end)
                        pcall(function() gMainPhoneUtils.CloseMainPhonePanel(true) end)
                        pcall(function() self:OnBtnClose() end)
                        return
                    else
                        pcall(function()
                            if gDisplayMessageMgr and gDisplayMessageMgr.ShowMessageContent then
                                gDisplayMessageMgr:ShowMessageContent("Map Click: Target outside world bounds")
                            end
                        end)
                        return
                    end
                end
                if origOnMainClick then return origOnMainClick(self, evtData) end
            end
        end
        if C_InteractionManager then
            local origCheck = C_InteractionManager.CheckUnitPcBtnShow
            C_InteractionManager.CheckUnitPcBtnShow = function(self, pid)
                local myUnit = gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit
                if myUnit and myUnit.Pid == pid then
                    return false
                end
                if origCheck then return origCheck(self, pid) end
                return false
            end
        end
        if gInteractionManager then
            local origCheckG = gInteractionManager.CheckUnitPcBtnShow
            gInteractionManager.CheckUnitPcBtnShow = function(self, pid)
                local myUnit = gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit
                if myUnit and myUnit.Pid == pid then
                    return false
                end
                if origCheckG then return origCheckG(self, pid) end
                return false
            end
        end
        local hudCtrl = GroupName2Class and GroupName2Class.PlayerHUDCtrl or C_PlayerHUDCtrl
        if hudCtrl and not hudCtrl._hideFHooked then
            hudCtrl._hideFHooked = true
            local oldHudUpdate = hudCtrl.Update
            hudCtrl.Update = function(self)
                local isCurrentControlled = false
                local myUnit = gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit
                if self.unit then
                    if myUnit and self.unit.Pid == myUnit.Pid then
                        isCurrentControlled = true
                    elseif self.unit.IsMe and (not myUnit or self.unit.Pid == myUnit.Pid) then
                        isCurrentControlled = true
                    end
                end
                if isCurrentControlled then
                    self.isBtnShowNew = false
                    pcall(function()
                        if self.SetPlayerHeadInfoVisible then self:SetPlayerHeadInfoVisible(true) end
                        if self.interactBtn then self.interactBtn:SetActive(false) end
                        if self.bindData then self.bindData.isBtnShow = false end
                    end)
                    return
                end
                if oldHudUpdate then return oldHudUpdate(self) end
            end
        end
        local hintStore = GroupName2Class and GroupName2Class.HintInfosHudStore or C_HintInfosHudStore
        if hintStore and not hintStore._filterPlayerFHooked then
            hintStore._filterPlayerFHooked = true
            local origRefreshPc = hintStore.RefreshPcBtnShow
            hintStore.RefreshPcBtnShow = function(self, force)
                pcall(function()
                    local myUnit = gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit
                    local btnMgr = L50 and L50.L50App and L50.L50App.L50Game and L50.L50App.L50Game.InteractBtnMgr
                    if myUnit and btnMgr and btnMgr.usefulList then
                        local myPid = myUnit.Pid
                        local i = 0
                        while i < btnMgr.usefulList.Count do
                            local item = btnMgr.usefulList[i]
                            if item and (item.pid == myPid or item.targetPid == myPid or (item.target and item.target == myUnit.PlayerObj)) then
                                btnMgr.usefulList:RemoveAt(i)
                            else
                                i = i + 1
                            end
                        end
                    end
                end)
                if origRefreshPc then return origRefreshPc(self, force) end
            end
        end
        local switchMgr = gSwitchSpiritManager or (GroupName2Class and GroupName2Class.SwitchSpiritManager)
        if switchMgr and not switchMgr._fixSwapHooked then
            switchMgr._fixSwapHooked = true
            local origBeforeSet = switchMgr.BeforeSetChangeUnit
            switchMgr.BeforeSetChangeUnit = function(self, spiritUnitPid, noClearold)
                local oldUnit = gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit
                local newUnit = gCS and gCS.SceneDataMgr and gCS.SceneDataMgr.GetUnit(spiritUnitPid)
                if oldUnit and newUnit and CS and CS.LX6 and CS.LX6.Manager and CS.LX6.Manager.SwitchSpiritManager and CS.LX6.Manager.SwitchSpiritManager.CopyNewCCMove then
                    pcall(function() CS.LX6.Manager.SwitchSpiritManager.CopyNewCCMove(oldUnit, newUnit) end)
                end
                local res = origBeforeSet and origBeforeSet(self, spiritUnitPid, noClearold)
                pcall(function()
                    local curUnit = (gCS and gCS.SceneDataMgr and gCS.SceneDataMgr.GetUnit(spiritUnitPid)) or (gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit)
                    if curUnit then
                        pcall(function() curUnit.IsMe = true end)
                        if curUnit.CharacterController then
                            pcall(function() curUnit.CharacterController.enabled = true end)
                        end
                        if CS and CS.LX6 and CS.LX6.Units and CS.LX6.Units.Module and CS.LX6.Units.Module.LockMoveDirModule then
                            pcall(function() CS.LX6.Units.Module.LockMoveDirModule.ClearLockMoveDir(curUnit) end)
                        end
                        if curUnit.RootMotionLockMoveAndRotate then
                            pcall(function() curUnit.RootMotionLockMoveAndRotate:ClearAll() end)
                            pcall(function() curUnit.RootMotionLockMoveAndRotate:ClearLockExtraRotation() end)
                        end
                        if curUnit.State then
                            curUnit.State.nowInteractiveAction = 0
                            curUnit.State.isFree = true
                            curUnit.State.isPause = false
                            curUnit.State.isLockMove = false
                            curUnit.State.isLockRotate = false
                        end
                        if curUnit.CCMove then
                            pcall(function() curUnit.CCMove:SetEnable(true) end)
                            pcall(function() curUnit.CCMove:ResetMoveSpeed() end)
                        end
                        if curUnit.UnitFightAction then
                            pcall(function() curUnit.UnitFightAction:ClearAllAction() end)
                            pcall(function() curUnit.UnitFightAction:StopAllAction() end)
                        end
                        if curUnit.Animator then
                            pcall(function() curUnit.Animator.speed = 1.0 end)
                        end
                        if gCS and gCS.BattleManager and gCS.BattleManager.RefreshAllSkills then
                            pcall(function() gCS.BattleManager.RefreshAllSkills(false, false) end)
                        end
                        local btnMgr = L50 and L50.L50App and L50.L50App.L50Game and L50.L50App.L50Game.InteractBtnMgr
                        if btnMgr then
                            pcall(function() btnMgr:RemoveBtnByType(curUnit.Pid, 1) end)
                            pcall(function() btnMgr:RemoveBtnByType(curUnit.Pid, 2) end)
                        end
                    end
                    if oldUnit and oldUnit.Pid ~= spiritUnitPid then
                        pcall(function() oldUnit.IsMe = false end)
                        local btnMgr = L50 and L50.L50App and L50.L50App.L50Game and L50.L50App.L50Game.InteractBtnMgr
                        if btnMgr and CS and CS.LX6 and CS.LX6.Interact then
                            pcall(function()
                                btnMgr:RemoveBtnByType(oldUnit.Pid, 1)
                                local btnInfo = CS.LX6.Interact.UnitBtnInfo and CS.LX6.Interact.UnitBtnInfo.New()
                                if btnInfo then
                                    btnInfo.pid = oldUnit.Pid
                                    btnInfo.target = oldUnit.PlayerObj
                                    btnInfo.text = "Switch Character"
                                    btnInfo.isAvailable = true
                                    local oldTemplateId = oldUnit.TemplateId or 15020967
                                    btnInfo.DoClick = function()
                                        pcall(function()
                                            if gClientToGameSceneDelegate and gClientToGameSceneDelegate.AskSwitchSpirit then
                                                gClientToGameSceneDelegate:AskSwitchSpirit(oldTemplateId)
                                            elseif gSwitchSpiritManager then
                                                local cUnit = gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit
                                                if cUnit and oldUnit and CS and CS.LX6 and CS.LX6.Manager and CS.LX6.Manager.SwitchSpiritManager and CS.LX6.Manager.SwitchSpiritManager.CopyNewCCMove then
                                                    CS.LX6.Manager.SwitchSpiritManager.CopyNewCCMove(cUnit, oldUnit)
                                                end
                                                gSwitchSpiritManager:BeforeSetChangeUnit(oldUnit.Pid, false)
                                            end
                                        end)
                                    end
                                    btnMgr:AddBtn(btnInfo)
                                end
                            end)
                        end
                    end
                end)
                return res
            end
        end
        local sceneImpl = GameSceneToClientImpl or (package and package.loaded and package.loaded["LX6/Service/GameSceneToClientImpl"])
        if sceneImpl and not sceneImpl._weatherRainHooked then
            sceneImpl._weatherRainHooked = true
            local origWeather = sceneImpl.SyncPlayerWeather
            sceneImpl.SyncPlayerWeather = function(weatherTypeId, nextWeatherTypeId, transitionSecond)
                if origWeather then origWeather(weatherTypeId, nextWeatherTypeId, transitionSecond) end
                pcall(function()
                    if CS and CS.CTT3 and CS.CTT3.Weather and CS.CTT3.Weather.WeatherBridge then
                        CS.CTT3.Weather.WeatherBridge.SetWeather(weatherTypeId, transitionSecond or 2.0)
                        if weatherTypeId == 3 or weatherTypeId == 4 then
                            CS.CTT3.Weather.WeatherBridge.SetGPURainActive(true)
                        else
                            CS.CTT3.Weather.WeatherBridge.SetGPURainActive(false)
                        end
                    end
                end)
            end
        end
        if gBuyHouseUtils then
            gBuyHouseUtils.CheckHasBuyTheHouse = function(houseId) return true end
            gBuyHouseUtils.CheckBuyHouseMoneyEnough = function(houseId) return true end
        end
        if C_PlayerItemManager then
            C_PlayerItemManager.GetPackItemNum = function(self, id) return 999999 end
        end
        if gPlayerItemManager then
            gPlayerItemManager.GetPackItemNum = function(self, id) return 999999 end
        end
        local photoStore = GroupName2Class and GroupName2Class.PhotoPanelStore or C_PhotoPanelStore
        if photoStore and not photoStore._selfieHooked then
            photoStore._selfieHooked = true
            local origOnShowPhoto = photoStore.OnShow
            photoStore.OnShow = function(self, ...)
                self.selectedSpirit = self.selectedSpirit or (gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit and gCS.MyPlayerManager.PlayerUnit.TemplateId) or 15020967
                if origOnShowPhoto then origOnShowPhoto(self, ...) end
            end
        end
        if gLuaClient and not gLuaClient._hotkeyHooked then
            gLuaClient._hotkeyHooked = true
            local oldClientUpdate = gLuaClient.OnUpdate
            gLuaClient.OnUpdate = function(self, ...)
                if oldClientUpdate then oldClientUpdate(self, ...) end
                if CheckCustomHotkeys then CheckCustomHotkeys() end
            end
        end
        if gLuaClient and gLuaClient.ForceUpdateArray and not gLuaClient._hotkeyForceRegistered then
            gLuaClient._hotkeyForceRegistered = true
            table.insert(gLuaClient.ForceUpdateArray, function()
                if CheckCustomHotkeys then CheckCustomHotkeys() end
            end)
        end
    end)
    pcall(function()
        local dm = CS and CS.L50 and CS.L50.Script and CS.L50.Script.LX6 and CS.L50.Script.LX6.Security and CS.L50.Script.LX6.Security.DavinciMgr and CS.L50.Script.LX6.Security.DavinciMgr.Instance
        if dm then
            pcall(function()
                local t = dm:GetType()
                local flags = 36
                pcall(function() flags = System.Reflection.BindingFlags.NonPublic:ToInt() + System.Reflection.BindingFlags.Instance:ToInt() end)
                local fDet = t:GetField("_detectors", flags)
                if fDet then
                    local list = fDet:GetValue(dm)
                    if list then list:Clear() end
                end
                local fCol = t:GetField("_collectors", flags)
                if fCol then
                    local list = fCol:GetValue(dm)
                    if list then list:Clear() end
                end
            end)
        end
    end)
    pcall(function()
        local nm = (CS and CS.LX6 and CS.LX6.Engine and CS.LX6.Engine.NetworkManager and CS.LX6.Engine.NetworkManager.Instance) or (gCS and gCS.NetworkManager and gCS.NetworkManager.Instance)
        if nm then
            nm.CheckNetwork = false
            if CS and CS.LX6 and CS.LX6.Engine and CS.LX6.Engine.NetworkManager then
                CS.LX6.Engine.NetworkManager.SilentReconnectEnabled = true
            end
            pcall(function()
                local t = nm:GetType()
                local flags = 36
                pcall(function() flags = System.Reflection.BindingFlags.NonPublic:ToInt() + System.Reflection.BindingFlags.Instance:ToInt() end)
                local fFocus = t:GetField("checkFocusChanged", flags)
                if fFocus then fFocus:SetValue(nm, false) end
                local fPing = t:GetField("checkPingpongTimeOut", flags)
                if fPing then fPing:SetValue(nm, false) end
                local fCheckNet = t:GetField("checkNetwork", flags)
                if fCheckNet then fCheckNet:SetValue(nm, false) end
                if nm.CancelDelayShowReconnectPanel then nm:CancelDelayShowReconnectPanel() end
                if nm.ClearCheckNeedReconnect then nm:ClearCheckNeedReconnect() end
            end)
        end
    end)
    pcall(function()
        local lmCS = (CS and CS.LX6 and CS.LX6.Manager and CS.LX6.Manager.LoginManager and CS.LX6.Manager.LoginManager.Instance) or (gCS and gCS.LoginManager and gCS.LoginManager.Instance)
        if lmCS then
            lmCS.CheckLoginConnected = false
            pcall(function()
                if lmCS.ClearReconnectState then lmCS:ClearReconnectState() end
                if lmCS.ClearLoginTimeoutCo then lmCS:ClearLoginTimeoutCo() end
            end)
        end
        local lm = gLoginManager or (GroupName2Class and GroupName2Class.LoginManager) or C_LoginManager
        if lm then
            lm.CheckNetworkState = function() end
            lm.OnUpdate_CheckNet = function() end
            lm.StopReconCo = function() end
            lm.DoKickToLogin = function() end
            lm.KickToLogin = function() end
            lm.RetryServerInfo = function() return true end
        end
    end)
    pcall(function()
        local gu = (CS and CS.LX6 and CS.LX6.Utils and CS.LX6.Utils.GuiUtils) or (gCS and gCS.GuiUtils)
        if gu then
            gu.ShowReconnectMessage = function() end
            gu.ShowDisconnectMessage = function() end
            gu.ShowServerDonw = function() end
        end
        if gClientToAvatarDelegate then gClientToAvatarDelegate.DavinciCode = function() end end
        if ClientToAvatarDelegate then ClientToAvatarDelegate.DavinciCode = function() end end
    end)
    pcall(function()
        local bombStore = GroupName2Class and GroupName2Class.CommonBombStore or C_CommonBombStore
        if bombStore and not bombStore._reconnectHooked then
            bombStore._reconnectHooked = true
            local oldOnShow = bombStore.OnShow
            bombStore.OnShow = function(self, panelId, data)
                if data then
                    local t1 = tostring(data.tips1Text or "")
                    local t2 = tostring(data.tips2Text or "")
                    local cBtn = tostring(data.confirmBtnText or "")
                    local all = t1 .. " " .. t2 .. " " .. cBtn
                    if string.find(all, "重连") or string.find(all, "Reconnect") or string.find(all, "断开") or string.find(all, "网络") or string.find(all, "Network") or string.find(all, "connect") then
                        pcall(function()
                            if gPanelManager then gPanelManager:Close(panelId or gPanelId.S_COMMON_BOMB_PANEL) end
                            if gDisplayMessageMgr then gDisplayMessageMgr:CloseBomb() end
                        end)
                        return
                    end
                end
                if oldOnShow then return oldOnShow(self, panelId, data) end
            end
        end
        if gPanelManager and not gPanelManager._bombFilterHooked then
            gPanelManager._bombFilterHooked = true
            local oldCheckShow = gPanelManager.CheckShow
            gPanelManager.CheckShow = function(self, panelId, params, ...)
                if panelId == (gPanelId and gPanelId.S_COMMON_BOMB_PANEL) and params then
                    local t1 = tostring(params.tips1Text or "")
                    local t2 = tostring(params.tips2Text or "")
                    local cBtn = tostring(params.confirmBtnText or "")
                    local all = t1 .. " " .. t2 .. " " .. cBtn
                    if string.find(all, "重连") or string.find(all, "Reconnect") or string.find(all, "断开") or string.find(all, "网络") or string.find(all, "Network") or string.find(all, "connect") then
                        return nil
                    end
                end
                if oldCheckShow then return oldCheckShow(self, panelId, params, ...) end
            end
        end
        if gDisplayMessageMgr and not gDisplayMessageMgr._bombFilterHooked then
            gDisplayMessageMgr._bombFilterHooked = true
            local oldShowBomb = gDisplayMessageMgr.ShowBomb
            gDisplayMessageMgr.ShowBomb = function(self, params)
                if params and params.tips1Text and type(params.tips1Text) == "string" then
                    local t = params.tips1Text
                    if string.find(t, "重连") or string.find(t, "Reconnect") or string.find(t, "网络连接已断开") or string.find(t, "network") or string.find(t, "Network") then
                        return
                    end
                end
                if oldShowBomb then return oldShowBomb(self, params) end
            end
        end
    end)
    pcall(function()
        if gCS and gCS.LX6 and gCS.LX6.Engine and gCS.LX6.Engine.ResourceManager then
            if gCS.LX6.Engine.ResourceManager.SwitchShaderWarmup then gCS.LX6.Engine.ResourceManager.SwitchShaderWarmup(false) end
            if gCS.LX6.Engine.ResourceManager.IsNeedWarmupPSO then gCS.LX6.Engine.ResourceManager.IsNeedWarmupPSO = function() return false end end
        end
    end)
    pcall(function()
        if CS and CS.LX6 and CS.LX6.Engine and CS.LX6.Engine.ResourceManager then
            if CS.LX6.Engine.ResourceManager.SwitchShaderWarmup then CS.LX6.Engine.ResourceManager.SwitchShaderWarmup(false) end
            if CS.LX6.Engine.ResourceManager.IsNeedWarmupPSO then CS.LX6.Engine.ResourceManager.IsNeedWarmupPSO = function() return false end end
        end
    end)
end

ProcessDebugCommand = function(cmd)
    if not cmd or type(cmd) ~= "string" then return end
    if cmd == "UNSTUCK_BLACKSCREEN" then
        pcall(function()
            if gBlackScreenManager then gBlackScreenManager:ClearTransition(nil, true) end
            if gVideoManager then gVideoManager:CloseBlackScreen() end
            if gPanelManager and gPanelId and gPanelId.S_VIDEO_PLAYER_PANEL then
                gPanelManager:CloseWindow(gPanelId.S_VIDEO_PLAYER_PANEL)
            end
            if LX6 and LX6.GUI and LX6.GUI.GuiMgr and gPanelId and gPanelId.COMMON_BLACK_TRANSITION then
                LX6.GUI.GuiMgr.Instance:SetShowScenePanel(false, gPanelId.COMMON_BLACK_TRANSITION)
                gPanelManager:RemoveVisibleMode(LX6.Manager.VisibleControlType.CommonBlack)
                LX6.Manager.GameInputManager.SetEnableInput(gPanelId.COMMON_BLACK_TRANSITION)
            end
        end)
    elseif string.sub(cmd, 1, 14) == "PLAY_TIMELINE:" then
        local arg = string.sub(cmd, 15)
        pcall(function()
            if gTimelineManager and gTimelineManager.Timeline_LoadAndPlay then
                gTimelineManager:Timeline_LoadAndPlay(arg, nil)
            elseif gTimelineManager and gTimelineManager.PlayTimeline then
                gTimelineManager:PlayTimeline(arg)
            elseif gDramaManager and gDramaManager.PlayTimeline then
                gDramaManager:PlayTimeline(arg)
            elseif gCS and gCS.LuaUtils and gCS.LuaUtils.PlayTimeline then
                gCS.LuaUtils.PlayTimeline(arg)
            end
        end)
    elseif string.sub(cmd, 1, 14) == "PLAY_CUTSCENE:" then
        local arg = string.sub(cmd, 15)
        local numId = tonumber(arg)
        pcall(function()
            if numId and gPanelManager and gPanelId and gPanelId.S_VIDEO_PLAYER_PANEL then
                gPanelManager:OpenWindow(gPanelId.S_VIDEO_PLAYER_PANEL, { videoId = numId })
            elseif gTimelineManager and gTimelineManager.Timeline_LoadAndPlay then
                gTimelineManager:Timeline_LoadAndPlay(arg, nil)
            elseif gVideoManager and gVideoManager.PlayVideo then
                gVideoManager:PlayVideo(numId or arg)
            end
        end)
    elseif string.sub(cmd, 1, 11) == "SPAWN_ENEMY" then
        local p1, p2, p3 = string.match(string.sub(cmd, 12), "^:?([^:]*):?([^:]*):?([^:]*)")
        local reqId = tonumber(p1)
        local enemyId = reqId or (function()
            local id = 40900579
            pcall(function()
                if LTConfig and LTConfig.AutoTestBossTestConfig and LTConfig.AutoTestBossTestConfig.count and LTConfig.AutoTestBossTestConfig.count > 0 then
                    for i = 0, LTConfig.AutoTestBossTestConfig.count - 1 do
                        local cfg = LTConfig.AutoTestBossTestConfig.LoadAt(i)
                        if cfg and cfg.BossId and #cfg.BossId > 0 and cfg.BossId[1] and cfg.BossId[1].EnemyId then
                            id = cfg.BossId[1].EnemyId
                            return
                        end
                    end
                end
            end)
            return id
        end)()
        local camp = tonumber(p2) or 0
        if camp == 2 then camp = 0 end
        local count = tonumber(p3) or 1
        pcall(function()
            if gCS and gCS.LuaUtils and gCS.LuaUtils.AddEnemy then
                gCS.LuaUtils.AddEnemy(enemyId, 1, camp, count)
            elseif gCS and gCS.GmUtils and gCS.GmUtils.AddEnemyWithCamp then
                gCS.GmUtils.AddEnemyWithCamp(enemyId, camp)
            elseif gCS and gCS.GmUtils and gCS.GmUtils.AddEnemy then
                gCS.GmUtils.AddEnemy(enemyId)
            end
            if gClientToGameSceneGMDelegate and gClientToGameSceneGMDelegate.GmAddEnemyByPlayer then
                pcall(function() gClientToGameSceneGMDelegate:GmAddEnemyByPlayer(enemyId, camp) end)
            end
            pcall(function()
                if gDisplayMessageMgr and gDisplayMessageMgr.ShowMessageContent then
                    gDisplayMessageMgr:ShowMessageContent("Spawned Enemy ID: " .. tostring(enemyId))
                end
                if gCS and gCS.MessageTipsMgr and gCS.MessageTipsMgr.ShowMessageTips then
                    gCS.MessageTipsMgr:ShowMessageTips("Spawned Enemy ID: " .. tostring(enemyId))
                end
            end)
        end)
    elseif cmd == "OPEN_MONSTER_PANEL" then
        pcall(function()
            if gPanelManager and gPanelId and gPanelId.S_SKILL_DEBUG_PANEL then
                gPanelManager:CheckShow(gPanelId.S_SKILL_DEBUG_PANEL, { ShowAddEnemy = true })
            end
            pcall(function()
                if gDisplayMessageMgr and gDisplayMessageMgr.ShowMessageContent then
                    gDisplayMessageMgr:ShowMessageContent("Opened Monster Spawn Menu")
                end
            end)
        end)
    elseif cmd == "TOGGLE_CLOTHES" then
        pcall(function()
            local unit = gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit
            if not unit or not unit.PlayerObj then return end
            _G._clothesHidden = not _G._clothesHidden
            local fs = nil
            pcall(function()
                if CS and CS.LX6 and CS.LX6.Share and CS.LX6.Share.FashionSlot then
                    fs = unit.PlayerObj:GetComponentInChildren(typeof(CS.LX6.Share.FashionSlot))
                end
            end)
            if not fs then
                pcall(function()
                    fs = unit.FashionSlot or (unit.ModelSlot and unit.ModelSlot.FashionSlot)
                end)
            end
            if fs then
                pcall(function()
                    local clothesSlots = { fs.Cloth, fs.Bottom, fs.Dress, fs.Bag, fs.Hood, fs.Belt, fs.Necklace }
                    for _, r in ipairs(clothesSlots) do
                        if r then r.enabled = not _G._clothesHidden end
                    end
                    if fs.SpProps then
                        for i = 0, fs.SpProps.Count - 1 do
                            local r = fs.SpProps[i]
                            if r then r.enabled = not _G._clothesHidden end
                        end
                    end
                    local keepSlots = { fs.Face, fs.Hair, fs.Hair01, fs.Hair02, fs.Ear, fs.Tail, fs.Gloves, fs.Shoes, fs.Sleeve }
                    for _, r in ipairs(keepSlots) do
                        if r then r.enabled = true end
                    end
                end)
            end
            local smrs = unit.PlayerObj:GetComponentsInChildren(typeof(UnityEngine.SkinnedMeshRenderer), true)
            if smrs then
                for i = 0, smrs.Length - 1 do
                    local smr = smrs[i]
                    if smr then
                        local n = string.lower(smr.name)
                        local isBodyLimb = string.find(n, "face") or string.find(n, "head") or string.find(n, "hair") or string.find(n, "eye") or string.find(n, "brow") or string.find(n, "mouth") or string.find(n, "ear") or string.find(n, "tail") or string.find(n, "arm") or string.find(n, "hand") or string.find(n, "glove") or string.find(n, "sleeve") or string.find(n, "leg") or string.find(n, "foot") or string.find(n, "feet") or string.find(n, "shoe") or string.find(n, "boot") or string.find(n, "skin") or string.find(n, "flesh") or string.find(n, "shenti") or string.find(n, "tou") or string.find(n, "lian") or string.find(n, "shou") or string.find(n, "bi") or string.find(n, "tui")
                        local isClothing = string.find(n, "cloth") or string.find(n, "coat") or string.find(n, "skirt") or string.find(n, "pant") or string.find(n, "dress") or string.find(n, "jacket") or string.find(n, "yifu") or string.find(n, "kuzi") or string.find(n, "qun") or string.find(n, "hood") or string.find(n, "cape") or string.find(n, "cloak") or string.find(n, "belt") or string.find(n, "bag") or string.find(n, "prop") or string.find(n, "necklace") or string.find(n, "acc")
                        if isBodyLimb and not (isClothing and not string.find(n, "arm") and not string.find(n, "hand") and not string.find(n, "leg") and not string.find(n, "foot") and not string.find(n, "face")) then
                            smr.enabled = true
                        elseif isClothing then
                            smr.enabled = not _G._clothesHidden
                        else
                            if not _G._clothesHidden then
                                smr.enabled = true
                            end
                        end
                    end
                end
            end
            pcall(function()
                local tip = _G._clothesHidden and "Clothes Hidden (Body Visible)" or "Clothes Shown"
                if gDisplayMessageMgr and gDisplayMessageMgr.ShowMessageContent then
                    gDisplayMessageMgr:ShowMessageContent(tip)
                end
                if gCS and gCS.MessageTipsMgr and gCS.MessageTipsMgr.ShowMessageTips then
                    gCS.MessageTipsMgr:ShowMessageTips(tip)
                end
            end)
        end)
    elseif string.sub(cmd, 1, 8) == "SET_FOG:" then
        local arg = string.sub(cmd, 9)
        local density = tonumber(arg) or 0
        pcall(function()
            if CS and CS.CTT3 and CS.CTT3.Weather and CS.CTT3.Weather.WeatherBridge then
                if density > 0 then
                    CS.CTT3.Weather.WeatherBridge.EnableExternalExpFogDensity(density)
                    CS.CTT3.Weather.WeatherBridge.EnableExternalSkyFogDensity(density)
                    CS.CTT3.Weather.WeatherBridge.EnableExternalExpFogStartDistance(0.0)
                    CS.CTT3.Weather.WeatherBridge.EnableExternalSkyFogStartDistance(0.0)
                else
                    CS.CTT3.Weather.WeatherBridge.DisableExternalExpFogDensity()
                    CS.CTT3.Weather.WeatherBridge.DisableExternalSkyFogDensity()
                    CS.CTT3.Weather.WeatherBridge.DisableExternalExpFogStartDistance()
                    CS.CTT3.Weather.WeatherBridge.DisableExternalSkyFogStartDistance()
                end
            end
            pcall(function()
                local Color = UnityEngine.Color
                UnityEngine.RenderSettings.fog = (density > 0)
                UnityEngine.RenderSettings.fogDensity = density
                UnityEngine.RenderSettings.fogMode = UnityEngine.FogMode.ExponentialSquared
                UnityEngine.RenderSettings.fogColor = Color(0.75, 0.78, 0.82, 1.0)
            end)
            local tip = density > 0 and ("Fog Set: " .. tostring(density)) or "Fog Cleared"
            if gDisplayMessageMgr and gDisplayMessageMgr.ShowMessageContent then
                gDisplayMessageMgr:ShowMessageContent(tip)
            end
            if gCS and gCS.MessageTipsMgr and gCS.MessageTipsMgr.ShowMessageTips then
                gCS.MessageTipsMgr:ShowMessageTips(tip)
            end
        end)
    elseif string.sub(cmd, 1, 12) == "SET_WEATHER:" then
        local arg = string.sub(cmd, 13)
        local wId = tonumber(arg) or 1
        pcall(function()
            if CS and CS.CTT3 and CS.CTT3.Weather and CS.CTT3.Weather.WeatherBridge then
                CS.CTT3.Weather.WeatherBridge.SetWeather(wId, 2.0)
                if wId == 3 or wId == 4 then
                    CS.CTT3.Weather.WeatherBridge.SetGPURainActive(true)
                else
                    CS.CTT3.Weather.WeatherBridge.SetGPURainActive(false)
                end
            end
            if CS and CS.LX6 and CS.LX6.Manager and CS.LX6.Manager.AtmosphereManager and CS.LX6.Manager.AtmosphereManager.Instance then
                pcall(function() CS.LX6.Manager.AtmosphereManager.Instance:SetWeather(wId, 2.0) end)
            end
            if gCS and gCS.WeatherManager and gCS.WeatherManager.SetWeather then
                gCS.WeatherManager:SetWeather(wId)
            end
            local tip = "Weather Set: " .. tostring(wId)
            if gDisplayMessageMgr and gDisplayMessageMgr.ShowMessageContent then
                gDisplayMessageMgr:ShowMessageContent(tip)
            end
            if gCS and gCS.MessageTipsMgr and gCS.MessageTipsMgr.ShowMessageTips then
                gCS.MessageTipsMgr:ShowMessageTips(tip)
            end
        end)
    end
end

local function HookNoticeTable(tbl)
    if not tbl or type(tbl) ~= "table" or tbl._cmdHooked then return end
    tbl._cmdHooked = true
    local oldSync = tbl.SyncNotice
    local newSync = function(...)
        local allArgs = {...}
        for i = 1, #allArgs do
            if type(allArgs[i]) == "string" and string.sub(allArgs[i], 1, 4) == "CMD:" then
                ProcessDebugCommand(string.sub(allArgs[i], 5))
                return
            end
        end
        if oldSync then return oldSync(...) end
    end
    if tbl._meta and type(tbl._meta) == "table" then
        tbl._meta.SyncNotice = newSync
    end
    tbl.SyncNotice = nil
    tbl.SyncNotice = newSync
    rawset(tbl, "SyncNotice", newSync)
end

local function HookDisplayMessageMgr()
    if gDisplayMessageMgr and not gDisplayMessageMgr._cmdHooked then
        gDisplayMessageMgr._cmdHooked = true
        local oldShow = gDisplayMessageMgr.ShowMessageContent
        gDisplayMessageMgr.ShowMessageContent = function(self, content, ...)
            if type(content) == "string" and string.sub(content, 1, 4) == "CMD:" then
                ProcessDebugCommand(string.sub(content, 5))
                return
            end
            return oldShow(self, content, ...)
        end
    end
end

local function HookAllNotices()
    pcall(function()
        if package and package.loaded then
            HookNoticeTable(package.loaded["LX6/Service/MasterToClientImpl"])
            HookNoticeTable(package.loaded["LX6/Service/GameToClientImpl"])
        end
        if MasterToClientImpl then HookNoticeTable(MasterToClientImpl) end
        if GameToClientImpl then HookNoticeTable(GameToClientImpl) end
        HookDisplayMessageMgr()
    end)
end

local oldRequire = require
require = function(mod)
    local res = oldRequire(mod)
    pcall(ApplyAllGlobalHooks)
    if mod == "LX6/Service/MasterToClientImpl" or mod == "LX6/Service/GameToClientImpl" then
        if type(res) == "table" then HookNoticeTable(res) end
    end
    pcall(HookAllNotices)
    return res
end

pcall(ApplyAllGlobalHooks)
pcall(HookAllNotices)
