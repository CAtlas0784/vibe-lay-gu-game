-- Ananta private-server fastpatch for client 4229938
-- GameSwitch defaults, Gacha active pool bypass, and safety hooks.

local M = {}

M.Sync = function(key, value)
    M[key] = value

    pcall(function()
        if gMessageManager and gEventConstants and gEventConstants.ON_GM_GAME_SWITCH_CHANGE then
            gMessageManager:SendMessage(gEventConstants.ON_GM_GAME_SWITCH_CHANGE)
        end
    end)
end

M.EnableBuzzCenter = true
M.EnableMall = true
M.EnableMallBundle = true
M.EnableMallRecommend = true
M.EnableMallDirectSale = true
M.EnableCheckIn = true
M.EnableTime = true
M.EnableDossier = true
M.EnableRadiantChest = true
M.EnableCloset = true
M.EnableGachaSystem = true
M.EnableSeasonalBattlePass = true
M.EnableBBChat = true
M.EnableScope = true
M.EnableParty = true
M.EnableSpiritTalent = true
M.EnablePhoto = true
M.EnableMail = true
M.EnablePhone = true
M.EnableFriends = true
M.EnableAchievement = true
M.EnableTutorial = true
M.EnableCityPedia = true
M.EnableNotices = true
M.EnableCustom = true
M.EnableInteractionAction = true
M.EnableDutyTerminal = true
M.EnableCatExpress = true
M.EnableEonBug = true
M.EnableJanitor = true
M.EnableRadioStation = true
M.EnableBubble = true
M.EnableFashionStore = true
M.Enable4SStore = true
M.EnableProfile = true
M.EnableClub = true
M.EnableRanking = true
M.EnableAkashicSystem = true
M.EnableActivity = true

gGameSwitch = M

-- Bypass CBT date expiration for Gacha pools and unlock all map/systems
local function ApplyAllGlobalHooks()
    pcall(function()
        if C_GachaManager then
            C_GachaManager.IsPoolActive = function() return true end
            C_GachaManager.CheckHasActiveClosetPool = function() return true end
        end
    end)
    pcall(function()
        if gBlockMgr then
            gBlockMgr.IsBlockUnlocked = function(self, blockId) return true end
        end
    end)
    pcall(function()
        if MapView then
            MapView.InFog = function(self, instanceId) return false end
            MapView.SetFogEnable = function(self, enable) self.enableFog = false end
        end
    end)
    pcall(function()
        if gMapSystem_FogMap then
            gMapSystem_FogMap.IsUnlocked = function(self, sceneId, x, z) return true end
        end
    end)
    pcall(function()
        if gMapUtils then
            gMapUtils.IsEntranceUnlocked = function(self, id) return true end
            gMapUtils.IsEntranceVisible = function(self, id) return true end
            gMapUtils.IsInUnlockBlockNear = function(self, blockId) return true end
        end
    end)
    pcall(function()
        if C_SystemUnlockMgr then
            C_SystemUnlockMgr.IsUnlock = function(self, id) return true end
            C_SystemUnlockMgr.IsUnlockGroup = function(self, ids) return true end
        end
    end)
    pcall(function()
        if C_CharMotionListPanelStore then
            C_CharMotionListPanelStore.CheckActionHasUnlocked = function(self, id) return true end
            C_CharMotionListPanelStore.CheckHasMeetFavor = function(self, id) return true end
        end
    end)
    pcall(function()
        if gMainPhoneUtils then
            gMainPhoneUtils.CheckSkinPartAvailable = function(targetSkinPartId) return true end
            gMainPhoneUtils.CheckAppCanShow = function(appId) return true end
            gMainPhoneUtils.CheckAppCanUse = function(appId) return true end
            gMainPhoneUtils.CheckAppSystemUnlocked = function(appId) return true end
        end
    end)
    pcall(function()
        if gTakePhotoUtils then
            gTakePhotoUtils.isDebugForce = true
            gTakePhotoUtils.PhotoPermission = true
        end
    end)
    pcall(function()
        if gTimeAppUtils then
            gTimeAppUtils.CheckIsTaskForbiddenChangeTime = function() return false end
        end
    end)
    pcall(function()
        if gMapSystem then
            gMapSystem.CanShowVehicleNavRoute = function(self) return true end
            gMapSystem.CheckCanShowVehicleNavLine = function(self) return true end
            pcall(function() gMapSystem:GmSwitchFlag("FogMap", false) end)
            pcall(function() gMapSystem:GmSwitchFlag("ShowAllMapArea", true) end)
            if gMapSystem.fogMap then
                gMapSystem.fogMap.IsUnlocked = function(self, sceneId, x, z) return true end
            end
        end
        if LX6 and LX6.Gps and LX6.Gps.MapFogDataMgr then
            LX6.Gps.MapFogDataMgr.IsInFog = function(sceneId, x, z) return false end
            pcall(function() LX6.Gps.MapFogDataMgr.SyncUnlockScene(101, true) end)
            pcall(function() LX6.Gps.MapFogDataMgr.SyncUnlockScene(102, true) end)
            pcall(function() LX6.Gps.MapFogDataMgr.SyncUnlockScene(103, true) end)
            pcall(function() LX6.Gps.MapFogDataMgr.SyncUnlockScene(1001, true) end)
        end
        if C_MapView_Fog then
            C_MapView_Fog.InFog = function(self, instanceId) return false end
            C_MapView_Fog.SetFogEnable = function(self, enable) end
        end
        if L50 and L50.Gm and L50.Gm.AutoQaFunctions then
            L50.Gm.AutoQaFunctions.GetMapClickToTeleport = function() return true end
        end
        if gCS and gCS.LuaUtils then
            gCS.LuaUtils.IsNotUseGM = false
        end
        local mapStore = GroupName2Class and GroupName2Class.NewMapPanelStore or C_NewMapPanelStore
        if mapStore and not mapStore._teleportHooked then
            mapStore._teleportHooked = true
            local origOnShow = mapStore.OnShow
            mapStore.OnShow = function(self, ...)
                pcall(function()
                    if self.fogNode then self.fogNode:SetActive(false) end
                    if self.fogRoot then self.fogRoot:SetActive(false) end
                end)
                if origOnShow then return origOnShow(self, ...) end
            end
            local origOnMainClick = mapStore.OnMainClick
            mapStore.OnMainClick = function(self, evtData)
                local isAlt = false
                pcall(function()
                    if UnityEngine and UnityEngine.Input and UnityEngine.KeyCode then
                        isAlt = UnityEngine.Input.GetKey(UnityEngine.KeyCode.LeftAlt) or UnityEngine.Input.GetKey(UnityEngine.KeyCode.RightAlt)
                    end
                end)
                if isAlt or (evtData and evtData.button == 1) or (L50 and L50.Gm and L50.Gm.AutoQaFunctions and L50.Gm.AutoQaFunctions.GetMapClickToTeleport()) then
                    local uiPos = self:GetPointerUIPos()
                    local texPos = self:TransformUIToTex(uiPos)
                    local areaId, worldPos = self:TryTransformTexToWorld(texPos)
                    if worldPos then
                        local playerY = 274.6
                        pcall(function()
                            if gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit then
                                local p = gCS.MyPlayerManager.PlayerUnit.Pos
                                if p and p.y > 10 then playerY = p.y end
                            end
                        end)
                        if L50 and L50.Gm and L50.Gm.AutoQaFunctions and L50.Gm.AutoQaFunctions.TeleportXYZ then
                            L50.Gm.AutoQaFunctions.TeleportXYZ(worldPos.x, playerY, worldPos.z)
                        elseif L50 and L50.Gm and L50.Gm.AutoQaFunctions and L50.Gm.AutoQaFunctions.TeleportToPos then
                            L50.Gm.AutoQaFunctions.TeleportToPos(worldPos.x, worldPos.z)
                        end
                        pcall(function() gMainPhoneUtils.CloseMainPhonePanel(true) end)
                        pcall(function() self:OnBtnClose() end)
                        return
                    end
                end
                if origOnMainClick then return origOnMainClick(self, evtData) end
            end
        end
        if C_InteractionManager then
            local origCheck = C_InteractionManager.CheckUnitPcBtnShow
            C_InteractionManager.CheckUnitPcBtnShow = function(self, pid)
                if gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit and gCS.MyPlayerManager.PlayerUnit.Pid == pid then
                    return false
                end
                if origCheck then return origCheck(self, pid) end
                return false
            end
        end
        if gInteractionManager then
            local origCheckG = gInteractionManager.CheckUnitPcBtnShow
            gInteractionManager.CheckUnitPcBtnShow = function(self, pid)
                if gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit and gCS.MyPlayerManager.PlayerUnit.Pid == pid then
                    return false
                end
                if origCheckG then return origCheckG(self, pid) end
                return false
            end
        end
        local hudCtrl = GroupName2Class and GroupName2Class.PlayerHUDCtrl or C_PlayerHUDCtrl
        if hudCtrl and not hudCtrl._hideFHooked then
            hudCtrl._hideFHooked = true
            local oldHudUpdate = hudCtrl.Update
            hudCtrl.Update = function(self)
                if self.unit and self.unit.IsMe then
                    pcall(function()
                        if self.interactBtn then
                            self.interactBtn:SetActive(false)
                        end
                    end)
                end
                if oldHudUpdate then return oldHudUpdate(self) end
            end
        end
        if gBuyHouseUtils then
            gBuyHouseUtils.CheckHasBuyTheHouse = function(houseId) return true end
            gBuyHouseUtils.CheckBuyHouseMoneyEnough = function(houseId) return true end
        end
        if C_PlayerItemManager then
            C_PlayerItemManager.GetPackItemNum = function(self, id) return 999999 end
        end
        if gPlayerItemManager then
            gPlayerItemManager.GetPackItemNum = function(self, id) return 999999 end
        end
        local photoStore = GroupName2Class and GroupName2Class.PhotoPanelStore or C_PhotoPanelStore
        if photoStore and not photoStore._selfieHooked then
            photoStore._selfieHooked = true
            local origOnShowPhoto = photoStore.OnShow
            photoStore.OnShow = function(self, ...)
                self.selectedSpirit = self.selectedSpirit or (gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit and gCS.MyPlayerManager.PlayerUnit.TemplateId) or 15020967
                if origOnShowPhoto then origOnShowPhoto(self, ...) end
            end
            local origSetMode = photoStore.SetCurrentPhotoMode
            photoStore.SetCurrentPhotoMode = function(self)
                if origSetMode then origSetMode(self) end
                if self.photoMode == 1 then
                    pcall(function()
                        if gCS and gCS.TransitionMgr then gCS.TransitionMgr.showMainCube = true end
                        if gCS and gCS.CameraDataMgr and gCS.CameraDataMgr.cinemachineManager then
                            gCS.CameraDataMgr.cinemachineManager:SwitchSelfiePhotoMode(true, 0.2)
                            gCS.CameraDataMgr.cinemachineManager:SetFov(68, 0, 0, false)
                        end
                    end)
                else
                    pcall(function()
                        if gCS and gCS.TransitionMgr then gCS.TransitionMgr.showMainCube = false end
                    end)
                end
            end
            local origOnClosePhoto = photoStore.OnClose
            photoStore.OnClose = function(self, ...)
                pcall(function()
                    local unit = gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit
                    if unit then
                        if gCS.ClimbManager and gCS.ClimbManager.SetLayerActionStateAndCheckTransition then
                            gCS.ClimbManager.SetLayerActionStateAndCheckTransition(unit, false, 42)
                        end
                        if MuGenStates and MuGenStates.Logic and MuGenStates.Logic.ABPVarManager and LTConfig and LTConfig.ABPVarConfig then
                            MuGenStates.Logic.ABPVarManager.SetBool(unit, LTConfig.ABPVarConfig.PhoneSelfie, false)
                        end
                    end
                    if gTakePhotoUtils and gTakePhotoUtils.PlayTakePhotoAction and LTConfig and LTConfig.TakePhotoActionConfig then
                        gTakePhotoUtils.PlayTakePhotoAction(LTConfig.TakePhotoActionConfig.NormalTakePhoto)
                    end
                end)
                if origOnClosePhoto then return origOnClosePhoto(self, ...) end
            end
        end
        if gHudMgr and not gHudMgr._customTickHooked then
            gHudMgr._customTickHooked = true
            local origHudUpdate = gHudMgr.Update
            gHudMgr.Update = function(self, ...)
                if origHudUpdate then origHudUpdate(self, ...) end
                pcall(function()
                    if UnityEngine and UnityEngine.Input and UnityEngine.KeyCode then
                        if UnityEngine.Input.GetKeyDown(UnityEngine.KeyCode.F8) then
                            if ProcessDebugCommand then ProcessDebugCommand("TOGGLE_CLOTHES") end
                        end
                        if UnityEngine.Input.GetKeyDown(UnityEngine.KeyCode.F7) then
                            if ProcessDebugCommand then ProcessDebugCommand("SPAWN_ENEMY:40900579:0:1") end
                        end
                    end
                end)
            end
        end
    end)
    pcall(function()
        if CS and CS.L50 and CS.L50.Script and CS.L50.Script.LX6 and CS.L50.Script.LX6.Security then
            local sec = CS.L50.Script.LX6.Security
            if sec.DavinciReport then
                sec.DavinciReport.Send = function() end
                sec.DavinciReport.Report = function() end
            end
            if sec.DavinciMgr then
                sec.DavinciMgr.CheckTimeScale = function() end
                sec.DavinciMgr.ReportTimeScale = function() end
                sec.DavinciMgr.CheckSpeed = function() end
            end
        end
        if CS and CS.LX6 and CS.LX6.Security then
            local sec = CS.LX6.Security
            if sec.DavinciReport then
                sec.DavinciReport.Send = function() end
                sec.DavinciReport.Report = function() end
            end
            if sec.DavinciMgr then
                sec.DavinciMgr.CheckTimeScale = function() end
                sec.DavinciMgr.ReportTimeScale = function() end
                sec.DavinciMgr.CheckSpeed = function() end
            end
        end
        if DavinciReport then
            DavinciReport.Send = function() end
            DavinciReport.Report = function() end
        end
        if DavinciMgr then
            DavinciMgr.CheckTimeScale = function() end
            DavinciMgr.ReportTimeScale = function() end
            DavinciMgr.CheckSpeed = function() end
        end
        if gDavinciMgr then
            gDavinciMgr.CheckTimeScale = function() end
            gDavinciMgr.ReportTimeScale = function() end
            gDavinciMgr.CheckSpeed = function() end
        end
    end)
    pcall(function()
        if gCS and gCS.LX6 and gCS.LX6.Engine and gCS.LX6.Engine.ResourceManager then
            if gCS.LX6.Engine.ResourceManager.SwitchShaderWarmup then gCS.LX6.Engine.ResourceManager.SwitchShaderWarmup(false) end
            if gCS.LX6.Engine.ResourceManager.IsNeedWarmupPSO then gCS.LX6.Engine.ResourceManager.IsNeedWarmupPSO = function() return false end end
        end
    end)
    pcall(function()
        if CS and CS.LX6 and CS.LX6.Engine and CS.LX6.Engine.ResourceManager then
            if CS.LX6.Engine.ResourceManager.SwitchShaderWarmup then CS.LX6.Engine.ResourceManager.SwitchShaderWarmup(false) end
            if CS.LX6.Engine.ResourceManager.IsNeedWarmupPSO then CS.LX6.Engine.ResourceManager.IsNeedWarmupPSO = function() return false end end
        end
    end)
end

local function ProcessDebugCommand(cmd)
    if not cmd or type(cmd) ~= "string" then return end
    if cmd == "UNSTUCK_BLACKSCREEN" then
        pcall(function()
            if gBlackScreenManager then gBlackScreenManager:ClearTransition(nil, true) end
            if gVideoManager then gVideoManager:CloseBlackScreen() end
            if gPanelManager and gPanelId and gPanelId.S_VIDEO_PLAYER_PANEL then
                gPanelManager:CloseWindow(gPanelId.S_VIDEO_PLAYER_PANEL)
            end
            if LX6 and LX6.GUI and LX6.GUI.GuiMgr and gPanelId and gPanelId.COMMON_BLACK_TRANSITION then
                LX6.GUI.GuiMgr.Instance:SetShowScenePanel(false, gPanelId.COMMON_BLACK_TRANSITION)
                gPanelManager:RemoveVisibleMode(LX6.Manager.VisibleControlType.CommonBlack)
                LX6.Manager.GameInputManager.SetEnableInput(gPanelId.COMMON_BLACK_TRANSITION)
            end
        end)
    elseif string.sub(cmd, 1, 14) == "PLAY_TIMELINE:" then
        local arg = string.sub(cmd, 15)
        pcall(function()
            if gTimelineManager and gTimelineManager.Timeline_LoadAndPlay then
                gTimelineManager:Timeline_LoadAndPlay(arg, nil)
            elseif gTimelineManager and gTimelineManager.PlayTimeline then
                gTimelineManager:PlayTimeline(arg)
            elseif gDramaManager and gDramaManager.PlayTimeline then
                gDramaManager:PlayTimeline(arg)
            elseif gCS and gCS.LuaUtils and gCS.LuaUtils.PlayTimeline then
                gCS.LuaUtils.PlayTimeline(arg)
            end
        end)
    elseif string.sub(cmd, 1, 14) == "PLAY_CUTSCENE:" then
        local arg = string.sub(cmd, 15)
        local numId = tonumber(arg)
        pcall(function()
            if numId and gPanelManager and gPanelId and gPanelId.S_VIDEO_PLAYER_PANEL then
                gPanelManager:OpenWindow(gPanelId.S_VIDEO_PLAYER_PANEL, { videoId = numId })
            elseif gTimelineManager and gTimelineManager.Timeline_LoadAndPlay then
                gTimelineManager:Timeline_LoadAndPlay(arg, nil)
            elseif gVideoManager and gVideoManager.PlayVideo then
                gVideoManager:PlayVideo(numId or arg)
            end
        end)
    elseif string.sub(cmd, 1, 12) == "SPAWN_ENEMY:" then
        local p1, p2, p3 = string.match(string.sub(cmd, 13), "([^:]+):?([^:]*):?([^:]*)")
        local enemyId = tonumber(p1) or 40900579
        local camp = tonumber(p2) or 0
        if camp == 2 then camp = 0 end
        local count = tonumber(p3) or 1
        pcall(function()
            if gCS and gCS.LuaUtils and gCS.LuaUtils.AddEnemy then
                gCS.LuaUtils.AddEnemy(enemyId, 1, camp, count)
            elseif gCS and gCS.GmUtils and gCS.GmUtils.AddEnemyWithCamp then
                gCS.GmUtils.AddEnemyWithCamp(enemyId, camp)
            elseif gCS and gCS.GmUtils and gCS.GmUtils.AddEnemy then
                gCS.GmUtils.AddEnemy(enemyId)
            end
            if gClientToGameSceneGMDelegate then
                pcall(function() gClientToGameSceneGMDelegate:GmAddEnemyByPlayer(enemyId, camp) end)
            end
            if gCS and gCS.MessageTipsMgr and gCS.MessageTipsMgr.ShowMessageTips then
                gCS.MessageTipsMgr:ShowMessageTips("Spawned Enemy ID: " .. enemyId)
            end
        end)
    elseif cmd == "TOGGLE_CLOTHES" then
        pcall(function()
            local unit = gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit
            if not unit or not unit.PlayerObj then return end
            _G._clothesHidden = not _G._clothesHidden
            local smrs = unit.PlayerObj:GetComponentsInChildren(typeof(UnityEngine.SkinnedMeshRenderer), true)
            if smrs then
                for i = 0, smrs.Length - 1 do
                    local smr = smrs[i]
                    local n = string.lower(smr.name)
                    local isBaseBody = string.find(n, "body") or string.find(n, "face") or string.find(n, "head") or string.find(n, "hair") or string.find(n, "eye") or string.find(n, "skin") or string.find(n, "shenti") or string.find(n, "tou") or string.find(n, "lian")
                    local isClothing = string.find(n, "cloth") or string.find(n, "coat") or string.find(n, "skirt") or string.find(n, "pant") or string.find(n, "dress") or string.find(n, "top") or string.find(n, "bottom") or string.find(n, "jacket") or string.find(n, "yifu") or string.find(n, "kuzi") or string.find(n, "qun") or string.find(n, "shoe") or string.find(n, "sock") or string.find(n, "hat") or string.find(n, "wa") or string.find(n, "xie") or string.find(n, "under") or string.find(n, "suit") or string.find(n, "acc")
                    if isClothing and not (string.find(n, "body") and not string.find(n, "cloth")) then
                        smr.enabled = not _G._clothesHidden
                    elseif isBaseBody then
                        smr.enabled = true
                    else
                        smr.enabled = not _G._clothesHidden
                    end
                end
            end
            if gCS and gCS.MessageTipsMgr and gCS.MessageTipsMgr.ShowMessageTips then
                gCS.MessageTipsMgr:ShowMessageTips(_G._clothesHidden and "Outfit Hidden (Base Body)" or "Outfit Shown")
            end
        end)
    end
end

local function HookNoticeTable(tbl)
    if not tbl or type(tbl) ~= "table" or tbl._cmdHooked then return end
    tbl._cmdHooked = true
    local oldSync = tbl.SyncNotice
    local newSync = function(...)
        local allArgs = {...}
        for i = 1, #allArgs do
            if type(allArgs[i]) == "string" and string.sub(allArgs[i], 1, 4) == "CMD:" then
                ProcessDebugCommand(string.sub(allArgs[i], 5))
                return
            end
        end
        if oldSync then return oldSync(...) end
    end
    if tbl._meta and type(tbl._meta) == "table" then
        tbl._meta.SyncNotice = newSync
    end
    tbl.SyncNotice = nil
    tbl.SyncNotice = newSync
    rawset(tbl, "SyncNotice", newSync)
end

local function HookDisplayMessageMgr()
    if gDisplayMessageMgr and not gDisplayMessageMgr._cmdHooked then
        gDisplayMessageMgr._cmdHooked = true
        local oldShow = gDisplayMessageMgr.ShowMessageContent
        gDisplayMessageMgr.ShowMessageContent = function(self, content, ...)
            if type(content) == "string" and string.sub(content, 1, 4) == "CMD:" then
                ProcessDebugCommand(string.sub(content, 5))
                return
            end
            return oldShow(self, content, ...)
        end
    end
end

local function HookAllNotices()
    pcall(function()
        if package and package.loaded then
            HookNoticeTable(package.loaded["LX6/Service/MasterToClientImpl"])
            HookNoticeTable(package.loaded["LX6/Service/GameToClientImpl"])
        end
        if MasterToClientImpl then HookNoticeTable(MasterToClientImpl) end
        if GameToClientImpl then HookNoticeTable(GameToClientImpl) end
        HookDisplayMessageMgr()
    end)
end

local oldRequire = require
require = function(mod)
    local res = oldRequire(mod)
    pcall(ApplyAllGlobalHooks)
    if mod == "LX6/Service/MasterToClientImpl" or mod == "LX6/Service/GameToClientImpl" then
        if type(res) == "table" then HookNoticeTable(res) end
    end
    pcall(HookAllNotices)
    return res
end

pcall(ApplyAllGlobalHooks)
pcall(HookAllNotices)
