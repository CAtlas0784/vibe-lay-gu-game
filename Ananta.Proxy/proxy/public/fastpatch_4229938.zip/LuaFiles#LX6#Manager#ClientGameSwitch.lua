-- Ananta private-server fastpatch for client 4229938
-- GameSwitch defaults, Gacha active pool bypass, and safety hooks.

local M = {}

M.Sync = function(key, value)
    M[key] = value

    pcall(function()
        if gMessageManager and gEventConstants and gEventConstants.ON_GM_GAME_SWITCH_CHANGE then
            gMessageManager:SendMessage(gEventConstants.ON_GM_GAME_SWITCH_CHANGE)
        end
    end)
end

M.EnableBuzzCenter = true
M.EnableMall = true
M.EnableMallBundle = true
M.EnableMallRecommend = true
M.EnableMallDirectSale = true
M.EnableCheckIn = true
M.EnableTime = true
M.EnableDossier = true
M.EnableRadiantChest = true
M.EnableCloset = true
M.EnableGachaSystem = true
M.EnableSeasonalBattlePass = true
M.EnableBBChat = true
M.EnableScope = true
M.EnableParty = true
M.EnableSpiritTalent = true
M.EnablePhoto = true
M.EnableMail = true
M.EnablePhone = true
M.EnableFriends = true
M.EnableAchievement = true
M.EnableTutorial = true
M.EnableCityPedia = true
M.EnableNotices = true
M.EnableCustom = true
M.EnableInteractionAction = true
M.EnableDutyTerminal = true
M.EnableCatExpress = true
M.EnableEonBug = true
M.EnableJanitor = true
M.EnableRadioStation = true
M.EnableBubble = true
M.EnableFashionStore = true
M.Enable4SStore = true
M.EnableProfile = true
M.EnableClub = true
M.EnableRanking = true
M.EnableAkashicSystem = true
M.EnableActivity = true

gGameSwitch = M

-- Bypass CBT date expiration for Gacha pools and unlock all map/systems
local function ApplyAllGlobalHooks()
    pcall(function()
        if C_GachaManager then
            C_GachaManager.IsPoolActive = function() return true end
            C_GachaManager.CheckHasActiveClosetPool = function() return true end
        end
    end)
    pcall(function()
        if gBlockMgr then
            gBlockMgr.IsBlockUnlocked = function(self, blockId) return true end
        end
    end)
    pcall(function()
        if MapView then
            MapView.InFog = function(self, instanceId) return false end
            MapView.SetFogEnable = function(self, enable) self.enableFog = false end
        end
    end)
    pcall(function()
        if gMapSystem_FogMap then
            gMapSystem_FogMap.IsUnlocked = function(self, sceneId, x, z) return true end
        end
    end)
    pcall(function()
        if gMapUtils then
            gMapUtils.IsEntranceUnlocked = function(self, id) return true end
            gMapUtils.IsEntranceVisible = function(self, id) return true end
            gMapUtils.IsInUnlockBlockNear = function(self, blockId) return true end
        end
    end)
    pcall(function()
        if C_SystemUnlockMgr then
            C_SystemUnlockMgr.IsUnlock = function(self, id) return true end
            C_SystemUnlockMgr.IsUnlockGroup = function(self, ids) return true end
        end
    end)
    pcall(function()
        if C_CharMotionListPanelStore then
            C_CharMotionListPanelStore.CheckActionHasUnlocked = function(self, id) return true end
            C_CharMotionListPanelStore.CheckHasMeetFavor = function(self, id) return true end
        end
    end)
    pcall(function()
        if gMainPhoneUtils then
            gMainPhoneUtils.CheckSkinPartAvailable = function(targetSkinPartId) return true end
            gMainPhoneUtils.CheckAppCanShow = function(appId) return true end
            gMainPhoneUtils.CheckAppCanUse = function(appId) return true end
            gMainPhoneUtils.CheckAppSystemUnlocked = function(appId) return true end
        end
    end)
    pcall(function()
        if gTakePhotoUtils then
            gTakePhotoUtils.isDebugForce = true
            gTakePhotoUtils.PhotoPermission = true
        end
    end)
    pcall(function()
        if gTimeAppUtils then
            gTimeAppUtils.CheckIsTaskForbiddenChangeTime = function() return false end
        end
    end)
    pcall(function()
        if gMapSystem then
            gMapSystem.CanShowVehicleNavRoute = function(self) return true end
            gMapSystem.CheckCanShowVehicleNavLine = function(self) return true end
            if gMapSystem.fogMap then
                gMapSystem.fogMap.IsUnlocked = function(self, sceneId, x, z) return true end
            end
        end
    end)
    pcall(function()
        if DavinciReport then
            DavinciReport.Send = function() end
            DavinciReport.Report = function() end
        end
        if DavinciMgr then
            DavinciMgr.CheckTimeScale = function() end
            DavinciMgr.ReportTimeScale = function() end
            DavinciMgr.CheckSpeed = function() end
        end
        if gDavinciMgr then
            gDavinciMgr.CheckTimeScale = function() end
            gDavinciMgr.ReportTimeScale = function() end
            gDavinciMgr.CheckSpeed = function() end
        end
    end)
    pcall(function()
        if gCS and gCS.LX6 and gCS.LX6.Engine and gCS.LX6.Engine.ResourceManager then
            if gCS.LX6.Engine.ResourceManager.SwitchShaderWarmup then gCS.LX6.Engine.ResourceManager.SwitchShaderWarmup(false) end
            if gCS.LX6.Engine.ResourceManager.IsNeedWarmupPSO then gCS.LX6.Engine.ResourceManager.IsNeedWarmupPSO = function() return false end end
        end
    end)
    pcall(function()
        if CS and CS.LX6 and CS.LX6.Engine and CS.LX6.Engine.ResourceManager then
            if CS.LX6.Engine.ResourceManager.SwitchShaderWarmup then CS.LX6.Engine.ResourceManager.SwitchShaderWarmup(false) end
            if CS.LX6.Engine.ResourceManager.IsNeedWarmupPSO then CS.LX6.Engine.ResourceManager.IsNeedWarmupPSO = function() return false end end
        end
    end)
end

local function HookMasterNotice()
    if MasterToClientImpl and not MasterToClientImpl._cmdHooked then
        MasterToClientImpl._cmdHooked = true
        local oldSyncNotice = MasterToClientImpl.SyncNotice
        MasterToClientImpl.SyncNotice = function(...)
            local allArgs = {...}
            local content = nil
            for i = 1, #allArgs do
                if type(allArgs[i]) == "string" then
                    content = allArgs[i]
                    break
                end
            end
            if content and string.sub(content, 1, 4) == "CMD:" then
                local cmd = string.sub(content, 5)
                if cmd == "UNSTUCK_BLACKSCREEN" then
                    pcall(function()
                        if gBlackScreenManager then
                            gBlackScreenManager:ClearTransition(nil, true)
                        end
                        if gVideoManager then
                            gVideoManager:CloseBlackScreen()
                        end
                        if gPanelManager and gPanelId and gPanelId.S_VIDEO_PLAYER_PANEL then
                            gPanelManager:CloseWindow(gPanelId.S_VIDEO_PLAYER_PANEL)
                        end
                        if LX6 and LX6.GUI and LX6.GUI.GuiMgr and gPanelId and gPanelId.COMMON_BLACK_TRANSITION then
                            LX6.GUI.GuiMgr.Instance:SetShowScenePanel(false, gPanelId.COMMON_BLACK_TRANSITION)
                            gPanelManager:RemoveVisibleMode(LX6.Manager.VisibleControlType.CommonBlack)
                            LX6.Manager.GameInputManager.SetEnableInput(gPanelId.COMMON_BLACK_TRANSITION)
                        end
                    end)
                    return
                elseif string.sub(cmd, 1, 14) == "PLAY_CUTSCENE:" then
                    local arg = string.sub(cmd, 15)
                    local numId = tonumber(arg)
                    pcall(function()
                        if numId and gPanelManager and gPanelId and gPanelId.S_VIDEO_PLAYER_PANEL then
                            gPanelManager:OpenWindow(gPanelId.S_VIDEO_PLAYER_PANEL, { videoId = numId })
                        elseif gTimelineManager and gTimelineManager.Timeline_LoadAndPlay then
                            gTimelineManager:Timeline_LoadAndPlay(arg, nil)
                        elseif gVideoManager and gVideoManager.PlayVideo then
                            gVideoManager:PlayVideo(numId or arg)
                        end
                    end)
                    return
                elseif string.sub(cmd, 1, 12) == "SPAWN_ENEMY:" then
                    local p1, p2, p3 = string.match(string.sub(cmd, 13), "([^:]+):?([^:]*):?([^:]*)")
                    local enemyId = tonumber(p1) or 40900579
                    local camp = tonumber(p2) or 2
                    local count = tonumber(p3) or 1
                    pcall(function()
                        if gCS and gCS.GmUtils and gCS.GmUtils.AddEnemyWithCamp then
                            gCS.GmUtils.AddEnemyWithCamp(enemyId, camp)
                        elseif gCS and gCS.GmUtils and gCS.GmUtils.AddEnemy then
                            gCS.GmUtils.AddEnemy(enemyId)
                        elseif gCS and gCS.LuaUtils and gCS.LuaUtils.AddEnemy then
                            gCS.LuaUtils.AddEnemy(enemyId, 1, camp, count)
                        elseif CS and CS.LX6 and CS.LX6.GmUtils and CS.LX6.GmUtils.AddEnemyWithCamp then
                            CS.LX6.GmUtils.AddEnemyWithCamp(enemyId, camp)
                        end
                    end)
                    return
                end
                return
            end
            if oldSyncNotice then
                return oldSyncNotice(...)
            end
        end
    end
end

local oldRequire = require
require = function(mod)
    local res = oldRequire(mod)
    pcall(ApplyAllGlobalHooks)
    pcall(HookMasterNotice)
    return res
end

pcall(ApplyAllGlobalHooks)
pcall(HookMasterNotice)
