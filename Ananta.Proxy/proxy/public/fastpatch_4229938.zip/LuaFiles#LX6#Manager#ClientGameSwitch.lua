-- Ananta private-server fastpatch for client 4229938
-- GameSwitch defaults, Gacha active pool bypass, and safety hooks.

local M = {}

M.Sync = function(key, value)
    M[key] = value

    pcall(function()
        if gMessageManager and gEventConstants and gEventConstants.ON_GM_GAME_SWITCH_CHANGE then
            gMessageManager:SendMessage(gEventConstants.ON_GM_GAME_SWITCH_CHANGE)
        end
    end)
end

M.EnableBuzzCenter = true
M.EnableMall = true
M.EnableMallBundle = true
M.EnableMallRecommend = true
M.EnableMallDirectSale = true
M.EnableCheckIn = true
M.EnableTime = true
M.EnableDossier = true
M.EnableRadiantChest = true
M.EnableCloset = true
M.EnableGachaSystem = true
M.EnableSeasonalBattlePass = true
M.EnableBBChat = true
M.EnableScope = true
M.EnableParty = true
M.EnableSpiritTalent = true
M.EnablePhoto = true
M.EnableMail = true
M.EnablePhone = true
M.EnableFriends = true
M.EnableAchievement = true
M.EnableTutorial = true
M.EnableCityPedia = true
M.EnableNotices = true
M.EnableCustom = true
M.EnableInteractionAction = true
M.EnableDutyTerminal = true
M.EnableCatExpress = true
M.EnableEonBug = true
M.EnableJanitor = true
M.EnableRadioStation = true
M.EnableBubble = true
M.EnableFashionStore = true
M.Enable4SStore = true
M.EnableProfile = true
M.EnableClub = true
M.EnableRanking = true
M.EnableAkashicSystem = true
M.EnableActivity = true

gGameSwitch = M

local ProcessDebugCommand
local _lastHotkeyFrame = -1
local function CheckCustomHotkeys()
    pcall(function()
        if not UnityEngine or not UnityEngine.Input then return end
        local curFrame = UnityEngine.Time and UnityEngine.Time.frameCount or -1
        if curFrame == _lastHotkeyFrame then return end
        _lastHotkeyFrame = curFrame

        local f8 = false
        local f7 = false
        local isShift = false
        pcall(function()
            f8 = UnityEngine.Input.GetKeyDown("f8")
            f7 = UnityEngine.Input.GetKeyDown("f7")
            isShift = UnityEngine.Input.GetKey("left shift") or UnityEngine.Input.GetKey("right shift")
        end)
        if not f8 and UnityEngine.KeyCode then
            pcall(function() f8 = UnityEngine.Input.GetKeyDown(UnityEngine.KeyCode.F8) end)
        end
        if not f7 and UnityEngine.KeyCode then
            pcall(function() f7 = UnityEngine.Input.GetKeyDown(UnityEngine.KeyCode.F7) end)
        end
        if not isShift and UnityEngine.KeyCode then
            pcall(function() isShift = UnityEngine.Input.GetKey(UnityEngine.KeyCode.LeftShift) or UnityEngine.Input.GetKey(UnityEngine.KeyCode.RightShift) end)
        end
        if not f8 and KeyCode then
            pcall(function() f8 = UnityEngine.Input.GetKeyDown(KeyCode.F8) end)
        end
        if not f7 and KeyCode then
            pcall(function() f7 = UnityEngine.Input.GetKeyDown(KeyCode.F7) end)
        end
        if not f8 then
            pcall(function() f8 = UnityEngine.Input.GetKeyDown(289) end)
        end
        if not f7 then
            pcall(function() f7 = UnityEngine.Input.GetKeyDown(288) end)
        end
        if not isShift then
            pcall(function() isShift = UnityEngine.Input.GetKey(304) or UnityEngine.Input.GetKey(303) end)
        end

        if f8 then
            if ProcessDebugCommand then ProcessDebugCommand("TOGGLE_CLOTHES") end
        end
        if f7 then
            if isShift then
                if ProcessDebugCommand then ProcessDebugCommand("OPEN_MONSTER_PANEL") end
            else
                if ProcessDebugCommand then ProcessDebugCommand("SPAWN_ENEMY") end
            end
        end
    end)
end

-- Bypass CBT date expiration for Gacha pools and unlock all map/systems
local function ApplyAllGlobalHooks()
    pcall(function()
        if C_GachaManager then
            C_GachaManager.IsPoolActive = function() return true end
            C_GachaManager.CheckHasActiveClosetPool = function() return true end
        end
    end)
    pcall(function()
        if gBlockMgr then
            gBlockMgr.IsBlockUnlocked = function(self, blockId) return true end
        end
    end)
    pcall(function()
        if MapView then
            MapView.InFog = function(self, instanceId) return false end
            MapView.SetFogEnable = function(self, enable) self.enableFog = false end
        end
    end)
    pcall(function()
        if gMapSystem_FogMap then
            gMapSystem_FogMap.IsUnlocked = function(self, sceneId, x, z) return true end
        end
    end)
    pcall(function()
        if gMapUtils then
            gMapUtils.IsEntranceUnlocked = function(self, id) return true end
            gMapUtils.IsEntranceVisible = function(self, id) return true end
            gMapUtils.IsInUnlockBlockNear = function(self, blockId) return true end
        end
    end)
    pcall(function()
        if C_SystemUnlockMgr then
            C_SystemUnlockMgr.IsUnlock = function(self, id) return true end
            C_SystemUnlockMgr.IsUnlockGroup = function(self, ids) return true end
        end
    end)
    pcall(function()
        if C_CharMotionListPanelStore then
            C_CharMotionListPanelStore.CheckActionHasUnlocked = function(self, id) return true end
            C_CharMotionListPanelStore.CheckHasMeetFavor = function(self, id) return true end
        end
    end)
    pcall(function()
        if gMainPhoneUtils then
            gMainPhoneUtils.CheckSkinPartAvailable = function(targetSkinPartId) return true end
            gMainPhoneUtils.CheckAppCanShow = function(appId) return true end
            gMainPhoneUtils.CheckAppCanUse = function(appId) return true end
            gMainPhoneUtils.CheckAppSystemUnlocked = function(appId) return true end
        end
    end)
    pcall(function()
        if gTakePhotoUtils then
            gTakePhotoUtils.isDebugForce = true
            gTakePhotoUtils.PhotoPermission = true
        end
    end)
    pcall(function()
        if gTimeAppUtils then
            gTimeAppUtils.CheckIsTaskForbiddenChangeTime = function() return false end
        end
    end)
    pcall(function()
        if gMapSystem then
            gMapSystem.CanShowVehicleNavRoute = function(self) return true end
            gMapSystem.CheckCanShowVehicleNavLine = function(self) return true end
            if gMapSystem.fogMap then
                gMapSystem.fogMap.IsUnlocked = function(self, sceneId, x, z) return true end
            end
        end
        if LX6 and LX6.Gps and LX6.Gps.MapFogDataMgr then
            LX6.Gps.MapFogDataMgr.IsInFog = function(sceneId, x, z) return false end
            pcall(function() LX6.Gps.MapFogDataMgr.SyncUnlockScene(101, true) end)
            pcall(function() LX6.Gps.MapFogDataMgr.SyncUnlockScene(102, true) end)
            pcall(function() LX6.Gps.MapFogDataMgr.SyncUnlockScene(103, true) end)
            pcall(function() LX6.Gps.MapFogDataMgr.SyncUnlockScene(1001, true) end)
        end
        if C_MapView_Fog then
            C_MapView_Fog.InFog = function(self, instanceId) return false end
            C_MapView_Fog.SetFogEnable = function(self, enable) end
        end
        if L50 and L50.Gm and L50.Gm.AutoQaFunctions then
            L50.Gm.AutoQaFunctions.GetMapClickToTeleport = function() return true end
        end
        if gCS and gCS.LuaUtils then
            gCS.LuaUtils.IsNotUseGM = false
        end
        local mapStore = GroupName2Class and GroupName2Class.NewMapPanelStore or C_NewMapPanelStore
        if mapStore and not mapStore._teleportHooked then
            mapStore._teleportHooked = true
            local origOnShow = mapStore.OnShow
            mapStore.OnShow = function(self, ...)
                pcall(function()
                    if self.fogNode then self.fogNode:SetActive(false) end
                    if self.fogRoot then self.fogRoot:SetActive(false) end
                end)
                if origOnShow then return origOnShow(self, ...) end
            end
            local origOnMainClick = mapStore.OnMainClick
            mapStore.OnMainClick = function(self, evtData)
                local isAlt = false
                pcall(function()
                    if UnityEngine and UnityEngine.Input and UnityEngine.KeyCode then
                        isAlt = UnityEngine.Input.GetKey(UnityEngine.KeyCode.LeftAlt) or UnityEngine.Input.GetKey(UnityEngine.KeyCode.RightAlt)
                    end
                end)
                if isAlt or (evtData and evtData.button == 1) or (L50 and L50.Gm and L50.Gm.AutoQaFunctions and L50.Gm.AutoQaFunctions.GetMapClickToTeleport()) then
                    local uiPos = self:GetPointerUIPos()
                    local texPos = self:TransformUIToTex(uiPos)
                    local areaId, worldPos = self:TryTransformTexToWorld(texPos)
                    if worldPos then
                        local playerY = 274.6
                        pcall(function()
                            if gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit then
                                local p = gCS.MyPlayerManager.PlayerUnit.Pos
                                if p and p.y > 10 then playerY = p.y end
                            end
                        end)
                        if L50 and L50.Gm and L50.Gm.AutoQaFunctions and L50.Gm.AutoQaFunctions.TeleportXYZ then
                            L50.Gm.AutoQaFunctions.TeleportXYZ(worldPos.x, playerY, worldPos.z)
                        elseif L50 and L50.Gm and L50.Gm.AutoQaFunctions and L50.Gm.AutoQaFunctions.TeleportToPos then
                            L50.Gm.AutoQaFunctions.TeleportToPos(worldPos.x, worldPos.z)
                        end
                        pcall(function() gMainPhoneUtils.CloseMainPhonePanel(true) end)
                        pcall(function() self:OnBtnClose() end)
                        return
                    end
                end
                if origOnMainClick then return origOnMainClick(self, evtData) end
            end
        end
        if C_InteractionManager then
            local origCheck = C_InteractionManager.CheckUnitPcBtnShow
            C_InteractionManager.CheckUnitPcBtnShow = function(self, pid)
                if gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit and gCS.MyPlayerManager.PlayerUnit.Pid == pid then
                    return false
                end
                if origCheck then return origCheck(self, pid) end
                return false
            end
        end
        if gInteractionManager then
            local origCheckG = gInteractionManager.CheckUnitPcBtnShow
            gInteractionManager.CheckUnitPcBtnShow = function(self, pid)
                if gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit and gCS.MyPlayerManager.PlayerUnit.Pid == pid then
                    return false
                end
                if origCheckG then return origCheckG(self, pid) end
                return false
            end
        end
        local hudCtrl = GroupName2Class and GroupName2Class.PlayerHUDCtrl or C_PlayerHUDCtrl
        if hudCtrl and not hudCtrl._hideFHooked then
            hudCtrl._hideFHooked = true
            local oldHudUpdate = hudCtrl.Update
            hudCtrl.Update = function(self)
                if self.unit and self.unit.IsMe then
                    pcall(function()
                        if self.interactBtn then
                            self.interactBtn:SetActive(false)
                        end
                    end)
                end
                if oldHudUpdate then return oldHudUpdate(self) end
            end
        end
        if gBuyHouseUtils then
            gBuyHouseUtils.CheckHasBuyTheHouse = function(houseId) return true end
            gBuyHouseUtils.CheckBuyHouseMoneyEnough = function(houseId) return true end
        end
        if C_PlayerItemManager then
            C_PlayerItemManager.GetPackItemNum = function(self, id) return 999999 end
        end
        if gPlayerItemManager then
            gPlayerItemManager.GetPackItemNum = function(self, id) return 999999 end
        end
        local photoStore = GroupName2Class and GroupName2Class.PhotoPanelStore or C_PhotoPanelStore
        if photoStore and not photoStore._selfieHooked then
            photoStore._selfieHooked = true
            local origOnShowPhoto = photoStore.OnShow
            photoStore.OnShow = function(self, ...)
                self.selectedSpirit = self.selectedSpirit or (gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit and gCS.MyPlayerManager.PlayerUnit.TemplateId) or 15020967
                if origOnShowPhoto then origOnShowPhoto(self, ...) end
            end
            local origSetMode = photoStore.SetCurrentPhotoMode
            photoStore.SetCurrentPhotoMode = function(self)
                if origSetMode then origSetMode(self) end
                if self.photoMode == 1 then
                    pcall(function()
                        if gCS and gCS.TransitionMgr then gCS.TransitionMgr.showMainCube = true end
                        if gCS and gCS.CameraDataMgr and gCS.CameraDataMgr.cinemachineManager then
                            gCS.CameraDataMgr.cinemachineManager:SwitchSelfiePhotoMode(true, 0.2)
                            gCS.CameraDataMgr.cinemachineManager:SetFov(68, 0, 0, false)
                        end
                    end)
                else
                    pcall(function()
                        if gCS and gCS.TransitionMgr then gCS.TransitionMgr.showMainCube = false end
                    end)
                end
            end
            local origOnClosePhoto = photoStore.OnClose
            photoStore.OnClose = function(self, ...)
                pcall(function()
                    local unit = gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit
                    if unit then
                        if gCS.ClimbManager and gCS.ClimbManager.SetLayerActionStateAndCheckTransition then
                            gCS.ClimbManager.SetLayerActionStateAndCheckTransition(unit, false, 42)
                        end
                        if MuGenStates and MuGenStates.Logic and MuGenStates.Logic.ABPVarManager and LTConfig and LTConfig.ABPVarConfig then
                            MuGenStates.Logic.ABPVarManager.SetBool(unit, LTConfig.ABPVarConfig.PhoneSelfie, false)
                        end
                    end
                    if gTakePhotoUtils and gTakePhotoUtils.PlayTakePhotoAction and LTConfig and LTConfig.TakePhotoActionConfig then
                        gTakePhotoUtils.PlayTakePhotoAction(LTConfig.TakePhotoActionConfig.NormalTakePhoto)
                    end
                end)
                if origOnClosePhoto then return origOnClosePhoto(self, ...) end
            end
        end
        if gLuaClient and not gLuaClient._hotkeyHooked then
            gLuaClient._hotkeyHooked = true
            local oldClientUpdate = gLuaClient.OnUpdate
            gLuaClient.OnUpdate = function(self, ...)
                if oldClientUpdate then oldClientUpdate(self, ...) end
                if CheckCustomHotkeys then CheckCustomHotkeys() end
            end
        end
        if gLuaClient and gLuaClient.ForceUpdateArray and not gLuaClient._hotkeyForceRegistered then
            gLuaClient._hotkeyForceRegistered = true
            table.insert(gLuaClient.ForceUpdateArray, function()
                if CheckCustomHotkeys then CheckCustomHotkeys() end
            end)
        end
    end)
    pcall(function()
        local dm = CS and CS.L50 and CS.L50.Script and CS.L50.Script.LX6 and CS.L50.Script.LX6.Security and CS.L50.Script.LX6.Security.DavinciMgr and CS.L50.Script.LX6.Security.DavinciMgr.Instance
        if dm then
            pcall(function()
                local t = dm:GetType()
                local flags = 36
                pcall(function() flags = System.Reflection.BindingFlags.NonPublic:ToInt() + System.Reflection.BindingFlags.Instance:ToInt() end)
                local fDet = t:GetField("_detectors", flags)
                if fDet then
                    local list = fDet:GetValue(dm)
                    if list then list:Clear() end
                end
                local fCol = t:GetField("_collectors", flags)
                if fCol then
                    local list = fCol:GetValue(dm)
                    if list then list:Clear() end
                end
            end)
        end
    end)
    pcall(function()
        local nm = (CS and CS.LX6 and CS.LX6.Engine and CS.LX6.Engine.NetworkManager and CS.LX6.Engine.NetworkManager.Instance) or (gCS and gCS.NetworkManager and gCS.NetworkManager.Instance)
        if nm then
            nm.CheckNetwork = false
            if CS and CS.LX6 and CS.LX6.Engine and CS.LX6.Engine.NetworkManager then
                CS.LX6.Engine.NetworkManager.SilentReconnectEnabled = true
            end
            pcall(function()
                local t = nm:GetType()
                local flags = 36
                pcall(function() flags = System.Reflection.BindingFlags.NonPublic:ToInt() + System.Reflection.BindingFlags.Instance:ToInt() end)
                local fFocus = t:GetField("checkFocusChanged", flags)
                if fFocus then fFocus:SetValue(nm, false) end
                local fPing = t:GetField("checkPingpongTimeOut", flags)
                if fPing then fPing:SetValue(nm, false) end
                local fCheckNet = t:GetField("checkNetwork", flags)
                if fCheckNet then fCheckNet:SetValue(nm, false) end
                if nm.CancelDelayShowReconnectPanel then nm:CancelDelayShowReconnectPanel() end
                if nm.ClearCheckNeedReconnect then nm:ClearCheckNeedReconnect() end
            end)
        end
    end)
    pcall(function()
        local lmCS = (CS and CS.LX6 and CS.LX6.Manager and CS.LX6.Manager.LoginManager and CS.LX6.Manager.LoginManager.Instance) or (gCS and gCS.LoginManager and gCS.LoginManager.Instance)
        if lmCS then
            lmCS.CheckLoginConnected = false
            pcall(function()
                if lmCS.ClearReconnectState then lmCS:ClearReconnectState() end
                if lmCS.ClearLoginTimeoutCo then lmCS:ClearLoginTimeoutCo() end
            end)
        end
        local lm = gLoginManager or (GroupName2Class and GroupName2Class.LoginManager) or C_LoginManager
        if lm then
            lm.CheckNetworkState = function() end
            lm.OnUpdate_CheckNet = function() end
            lm.StopReconCo = function() end
            lm.DoKickToLogin = function() end
            lm.KickToLogin = function() end
            lm.RetryServerInfo = function() return true end
        end
    end)
    pcall(function()
        local gu = (CS and CS.LX6 and CS.LX6.Utils and CS.LX6.Utils.GuiUtils) or (gCS and gCS.GuiUtils)
        if gu then
            gu.ShowReconnectMessage = function() end
            gu.ShowDisconnectMessage = function() end
            gu.ShowServerDonw = function() end
        end
        if gClientToAvatarDelegate then gClientToAvatarDelegate.DavinciCode = function() end end
        if ClientToAvatarDelegate then ClientToAvatarDelegate.DavinciCode = function() end end
    end)
    pcall(function()
        local bombStore = GroupName2Class and GroupName2Class.CommonBombStore or C_CommonBombStore
        if bombStore and not bombStore._reconnectHooked then
            bombStore._reconnectHooked = true
            local oldOnShow = bombStore.OnShow
            bombStore.OnShow = function(self, panelId, data)
                if data then
                    local t1 = tostring(data.tips1Text or "")
                    local t2 = tostring(data.tips2Text or "")
                    local cBtn = tostring(data.confirmBtnText or "")
                    local all = t1 .. " " .. t2 .. " " .. cBtn
                    if string.find(all, "重连") or string.find(all, "Reconnect") or string.find(all, "断开") or string.find(all, "网络") or string.find(all, "Network") or string.find(all, "connect") then
                        pcall(function()
                            if gPanelManager then gPanelManager:Close(panelId or gPanelId.S_COMMON_BOMB_PANEL) end
                            if gDisplayMessageMgr then gDisplayMessageMgr:CloseBomb() end
                        end)
                        return
                    end
                end
                if oldOnShow then return oldOnShow(self, panelId, data) end
            end
        end
        if gPanelManager and not gPanelManager._bombFilterHooked then
            gPanelManager._bombFilterHooked = true
            local oldCheckShow = gPanelManager.CheckShow
            gPanelManager.CheckShow = function(self, panelId, params, ...)
                if panelId == (gPanelId and gPanelId.S_COMMON_BOMB_PANEL) and params then
                    local t1 = tostring(params.tips1Text or "")
                    local t2 = tostring(params.tips2Text or "")
                    local cBtn = tostring(params.confirmBtnText or "")
                    local all = t1 .. " " .. t2 .. " " .. cBtn
                    if string.find(all, "重连") or string.find(all, "Reconnect") or string.find(all, "断开") or string.find(all, "网络") or string.find(all, "Network") or string.find(all, "connect") then
                        return nil
                    end
                end
                if oldCheckShow then return oldCheckShow(self, panelId, params, ...) end
            end
        end
        if gDisplayMessageMgr and not gDisplayMessageMgr._bombFilterHooked then
            gDisplayMessageMgr._bombFilterHooked = true
            local oldShowBomb = gDisplayMessageMgr.ShowBomb
            gDisplayMessageMgr.ShowBomb = function(self, params)
                if params and params.tips1Text and type(params.tips1Text) == "string" then
                    local t = params.tips1Text
                    if string.find(t, "重连") or string.find(t, "Reconnect") or string.find(t, "网络连接已断开") or string.find(t, "network") or string.find(t, "Network") then
                        return
                    end
                end
                if oldShowBomb then return oldShowBomb(self, params) end
            end
        end
    end)
    pcall(function()
        if gCS and gCS.LX6 and gCS.LX6.Engine and gCS.LX6.Engine.ResourceManager then
            if gCS.LX6.Engine.ResourceManager.SwitchShaderWarmup then gCS.LX6.Engine.ResourceManager.SwitchShaderWarmup(false) end
            if gCS.LX6.Engine.ResourceManager.IsNeedWarmupPSO then gCS.LX6.Engine.ResourceManager.IsNeedWarmupPSO = function() return false end end
        end
    end)
    pcall(function()
        if CS and CS.LX6 and CS.LX6.Engine and CS.LX6.Engine.ResourceManager then
            if CS.LX6.Engine.ResourceManager.SwitchShaderWarmup then CS.LX6.Engine.ResourceManager.SwitchShaderWarmup(false) end
            if CS.LX6.Engine.ResourceManager.IsNeedWarmupPSO then CS.LX6.Engine.ResourceManager.IsNeedWarmupPSO = function() return false end end
        end
    end)
end

ProcessDebugCommand = function(cmd)
    if not cmd or type(cmd) ~= "string" then return end
    if cmd == "UNSTUCK_BLACKSCREEN" then
        pcall(function()
            if gBlackScreenManager then gBlackScreenManager:ClearTransition(nil, true) end
            if gVideoManager then gVideoManager:CloseBlackScreen() end
            if gPanelManager and gPanelId and gPanelId.S_VIDEO_PLAYER_PANEL then
                gPanelManager:CloseWindow(gPanelId.S_VIDEO_PLAYER_PANEL)
            end
            if LX6 and LX6.GUI and LX6.GUI.GuiMgr and gPanelId and gPanelId.COMMON_BLACK_TRANSITION then
                LX6.GUI.GuiMgr.Instance:SetShowScenePanel(false, gPanelId.COMMON_BLACK_TRANSITION)
                gPanelManager:RemoveVisibleMode(LX6.Manager.VisibleControlType.CommonBlack)
                LX6.Manager.GameInputManager.SetEnableInput(gPanelId.COMMON_BLACK_TRANSITION)
            end
        end)
    elseif string.sub(cmd, 1, 14) == "PLAY_TIMELINE:" then
        local arg = string.sub(cmd, 15)
        pcall(function()
            if gTimelineManager and gTimelineManager.Timeline_LoadAndPlay then
                gTimelineManager:Timeline_LoadAndPlay(arg, nil)
            elseif gTimelineManager and gTimelineManager.PlayTimeline then
                gTimelineManager:PlayTimeline(arg)
            elseif gDramaManager and gDramaManager.PlayTimeline then
                gDramaManager:PlayTimeline(arg)
            elseif gCS and gCS.LuaUtils and gCS.LuaUtils.PlayTimeline then
                gCS.LuaUtils.PlayTimeline(arg)
            end
        end)
    elseif string.sub(cmd, 1, 14) == "PLAY_CUTSCENE:" then
        local arg = string.sub(cmd, 15)
        local numId = tonumber(arg)
        pcall(function()
            if numId and gPanelManager and gPanelId and gPanelId.S_VIDEO_PLAYER_PANEL then
                gPanelManager:OpenWindow(gPanelId.S_VIDEO_PLAYER_PANEL, { videoId = numId })
            elseif gTimelineManager and gTimelineManager.Timeline_LoadAndPlay then
                gTimelineManager:Timeline_LoadAndPlay(arg, nil)
            elseif gVideoManager and gVideoManager.PlayVideo then
                gVideoManager:PlayVideo(numId or arg)
            end
        end)
    elseif string.sub(cmd, 1, 11) == "SPAWN_ENEMY" then
        local p1, p2, p3 = string.match(string.sub(cmd, 12), "^:?([^:]*):?([^:]*):?([^:]*)")
        local reqId = tonumber(p1)
        local enemyId = reqId or (function()
            local id = 40900579
            pcall(function()
                if LTConfig and LTConfig.AutoTestBossTestConfig and LTConfig.AutoTestBossTestConfig.count and LTConfig.AutoTestBossTestConfig.count > 0 then
                    for i = 0, LTConfig.AutoTestBossTestConfig.count - 1 do
                        local cfg = LTConfig.AutoTestBossTestConfig.LoadAt(i)
                        if cfg and cfg.BossId and #cfg.BossId > 0 and cfg.BossId[1] and cfg.BossId[1].EnemyId then
                            id = cfg.BossId[1].EnemyId
                            return
                        end
                    end
                end
            end)
            return id
        end)()
        local camp = tonumber(p2) or 0
        if camp == 2 then camp = 0 end
        local count = tonumber(p3) or 1
        pcall(function()
            if gCS and gCS.LuaUtils and gCS.LuaUtils.AddEnemy then
                gCS.LuaUtils.AddEnemy(enemyId, 1, camp, count)
            elseif gCS and gCS.GmUtils and gCS.GmUtils.AddEnemyWithCamp then
                gCS.GmUtils.AddEnemyWithCamp(enemyId, camp)
            elseif gCS and gCS.GmUtils and gCS.GmUtils.AddEnemy then
                gCS.GmUtils.AddEnemy(enemyId)
            end
            if gClientToGameSceneGMDelegate and gClientToGameSceneGMDelegate.GmAddEnemyByPlayer then
                pcall(function() gClientToGameSceneGMDelegate:GmAddEnemyByPlayer(enemyId, camp) end)
            end
            pcall(function()
                if gDisplayMessageMgr and gDisplayMessageMgr.ShowMessageContent then
                    gDisplayMessageMgr:ShowMessageContent("Spawned Enemy ID: " .. tostring(enemyId))
                end
                if gCS and gCS.MessageTipsMgr and gCS.MessageTipsMgr.ShowMessageTips then
                    gCS.MessageTipsMgr:ShowMessageTips("Spawned Enemy ID: " .. tostring(enemyId))
                end
            end)
        end)
    elseif cmd == "OPEN_MONSTER_PANEL" then
        pcall(function()
            if gPanelManager and gPanelId and gPanelId.S_SKILL_DEBUG_PANEL then
                gPanelManager:CheckShow(gPanelId.S_SKILL_DEBUG_PANEL, { ShowAddEnemy = true })
            end
            pcall(function()
                if gDisplayMessageMgr and gDisplayMessageMgr.ShowMessageContent then
                    gDisplayMessageMgr:ShowMessageContent("Opened Monster Spawn Menu")
                end
            end)
        end)
    elseif cmd == "TOGGLE_CLOTHES" then
        pcall(function()
            local unit = gCS and gCS.MyPlayerManager and gCS.MyPlayerManager.PlayerUnit
            if not unit or not unit.PlayerObj then return end
            _G._clothesHidden = not _G._clothesHidden
            local smrs = unit.PlayerObj:GetComponentsInChildren(typeof(UnityEngine.SkinnedMeshRenderer), true)
            if smrs then
                for i = 0, smrs.Length - 1 do
                    local smr = smrs[i]
                    local n = string.lower(smr.name)
                    local isBaseBody = string.find(n, "body") or string.find(n, "face") or string.find(n, "head") or string.find(n, "hair") or string.find(n, "eye") or string.find(n, "skin") or string.find(n, "shenti") or string.find(n, "tou") or string.find(n, "lian")
                    local isClothing = string.find(n, "cloth") or string.find(n, "coat") or string.find(n, "skirt") or string.find(n, "pant") or string.find(n, "dress") or string.find(n, "top") or string.find(n, "bottom") or string.find(n, "jacket") or string.find(n, "yifu") or string.find(n, "kuzi") or string.find(n, "qun") or string.find(n, "shoe") or string.find(n, "sock") or string.find(n, "hat") or string.find(n, "wa") or string.find(n, "xie") or string.find(n, "under") or string.find(n, "suit") or string.find(n, "acc")
                    if isClothing and not (string.find(n, "body") and not string.find(n, "cloth")) then
                        smr.enabled = not _G._clothesHidden
                    elseif isBaseBody then
                        smr.enabled = true
                    else
                        smr.enabled = not _G._clothesHidden
                    end
                end
            end
            pcall(function()
                local tip = _G._clothesHidden and "Outfit Hidden (Base Body)" or "Outfit Shown"
                if gDisplayMessageMgr and gDisplayMessageMgr.ShowMessageContent then
                    gDisplayMessageMgr:ShowMessageContent(tip)
                end
                if gCS and gCS.MessageTipsMgr and gCS.MessageTipsMgr.ShowMessageTips then
                    gCS.MessageTipsMgr:ShowMessageTips(tip)
                end
            end)
        end)
    end
end

local function HookNoticeTable(tbl)
    if not tbl or type(tbl) ~= "table" or tbl._cmdHooked then return end
    tbl._cmdHooked = true
    local oldSync = tbl.SyncNotice
    local newSync = function(...)
        local allArgs = {...}
        for i = 1, #allArgs do
            if type(allArgs[i]) == "string" and string.sub(allArgs[i], 1, 4) == "CMD:" then
                ProcessDebugCommand(string.sub(allArgs[i], 5))
                return
            end
        end
        if oldSync then return oldSync(...) end
    end
    if tbl._meta and type(tbl._meta) == "table" then
        tbl._meta.SyncNotice = newSync
    end
    tbl.SyncNotice = nil
    tbl.SyncNotice = newSync
    rawset(tbl, "SyncNotice", newSync)
end

local function HookDisplayMessageMgr()
    if gDisplayMessageMgr and not gDisplayMessageMgr._cmdHooked then
        gDisplayMessageMgr._cmdHooked = true
        local oldShow = gDisplayMessageMgr.ShowMessageContent
        gDisplayMessageMgr.ShowMessageContent = function(self, content, ...)
            if type(content) == "string" and string.sub(content, 1, 4) == "CMD:" then
                ProcessDebugCommand(string.sub(content, 5))
                return
            end
            return oldShow(self, content, ...)
        end
    end
end

local function HookAllNotices()
    pcall(function()
        if package and package.loaded then
            HookNoticeTable(package.loaded["LX6/Service/MasterToClientImpl"])
            HookNoticeTable(package.loaded["LX6/Service/GameToClientImpl"])
        end
        if MasterToClientImpl then HookNoticeTable(MasterToClientImpl) end
        if GameToClientImpl then HookNoticeTable(GameToClientImpl) end
        HookDisplayMessageMgr()
    end)
end

local oldRequire = require
require = function(mod)
    local res = oldRequire(mod)
    pcall(ApplyAllGlobalHooks)
    if mod == "LX6/Service/MasterToClientImpl" or mod == "LX6/Service/GameToClientImpl" then
        if type(res) == "table" then HookNoticeTable(res) end
    end
    pcall(HookAllNotices)
    return res
end

pcall(ApplyAllGlobalHooks)
pcall(HookAllNotices)
